/*
 * immagine — la scena sintetica della fase 2.
 *
 * Serve a giudicare a occhio tre cose che il protocollo puo' sbagliare senza
 * dare errori (§8 di REFERENCE.md):
 *
 *   - la GEOMETRIA: una cornice di un pixel sui bordi esatti e quattro angoli
 *     etichettati.  Se l'immagine e' spostata, tagliata o allineata male, la
 *     cornice non torna — ed e' il sintomo di R4, R5 e R6;
 *   - la SCALA: una griglia da 100 px con le coordinate scritte sopra;
 *   - il MOVIMENTO: un orologio al millesimo e una barra che scorre.  Se i
 *     fotogrammi non arrivano, l'orologio si ferma; se arrivano e non si
 *     disegnano, resta nero (ed e' la differenza fra 1-5 e 6-7 di §8.1).
 *
 * Il buffer e' BGRX a 32 bit, lo stesso formato che PipeWire consegnera' nella
 * fase 3: cosi' il codificatore non cambia quando l'immagine diventa vera.
 *
 * Il buffer e' ALLINEATO (R4): larghezza multipla di 16, altezza di 64.  Il
 * bordo in eccesso viene RIEMPITO replicando l'ultima riga e l'ultima colonna,
 * non tagliato — il desktop resta della misura chiesta dal client.
 */
#pragma once

#include <glib.h>
#include <stdint.h>

typedef struct Immagine Immagine;

Immagine *immagine_nuova(uint32_t larghezza, uint32_t altezza);
void immagine_libera(Immagine *immagine);

/* Ridisegna la scena.  `millisecondi` e' il tempo da mostrare sull'orologio. */
void immagine_disegna(Immagine *immagine, int64_t millisecondi);

const uint8_t *immagine_pixel(const Immagine *immagine);
uint32_t immagine_passo(const Immagine *immagine);
uint32_t immagine_larghezza(const Immagine *immagine);
uint32_t immagine_altezza(const Immagine *immagine);
uint32_t immagine_larghezza_allineata(const Immagine *immagine);
uint32_t immagine_altezza_allineata(const Immagine *immagine);
