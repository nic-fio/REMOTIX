#include "server.h"

#include <errno.h>
#include <freerdp/channels/channels.h>
#include <freerdp/channels/drdynvc.h>
#include <freerdp/channels/wtsvc.h>
#include <freerdp/codec/color.h>
#include <freerdp/error.h>
#include <freerdp/freerdp.h>
#include <freerdp/peer.h>
#include <freerdp/server/rdpgfx.h>
#include <gio/gio.h>
#include <glib/gstdio.h>
#include <winpr/ssl.h>
#include <winpr/synch.h>

#include "autenticazione.h"
#include "codificatore.h"
#include "immagine.h"
#include "registro.h"

/* R2 — l'elenco DEVE essere completo, dalla piu' alta alla piu' bassa, e la
 * 10.6 ha due valori perche' quello della specifica era sbagliato e l'errata
 * [MS-RDPEGFX]-180912 lo corregge.  Ripiegare su una versione dove l'AVC e'
 * spento significa zero fotogrammi con mstsc. */
static const UINT32 versioni_egfx[] = {
	RDPGFX_CAPVERSION_107, RDPGFX_CAPVERSION_106, RDPGFX_CAPVERSION_106_ERR,
	RDPGFX_CAPVERSION_105, RDPGFX_CAPVERSION_104, RDPGFX_CAPVERSION_103,
	RDPGFX_CAPVERSION_102, RDPGFX_CAPVERSION_101, RDPGFX_CAPVERSION_10,
	RDPGFX_CAPVERSION_81,  RDPGFX_CAPVERSION_8,
};

typedef struct
{
	rdpContext ctx; /* DEVE essere il primo campo */

	Server *server;
	HANDLE vcm;
	HANDLE evento_stop;

	RdpgfxServerContext *gfx;
	gboolean gfx_aperto;
	gboolean gfx_pronto;
	UINT16 id_superficie;
	UINT32 id_fotogramma;
	gint in_volo;
	gboolean riscontri_sospesi;

	Codificatore *cod;
	Immagine *immagine;
	gint64 avvio_us;

	/* R14 — la guardia parte da NEGATO e solo il validatore la apre. */
	gboolean autenticato;
} ContestoPeer;

struct Server
{
	OpzioniServer opzioni;
	GSocketService *servizio;
	/*
	 * Si conservano i PEM come TESTO, non gli oggetti gia' costruiti.
	 *
	 * `freerdp_settings_set_pointer_len(FreeRDP_RdpServerCertificate, ...)`
	 * non copia: assegna il puntatore, e `freerdp_settings_free` lo libera
	 * insieme al peer.  Condividere un solo certificato fra le connessioni
	 * significa quindi che la PRIMA se lo porta via e la SECONDA usa memoria
	 * liberata — segfault dentro libcrypto, lontanissimo dalla causa.
	 * Costato il 4 agosto: il server moriva alla seconda connessione, e dal
	 * lato del client si vedeva solo «non si collega».
	 */
	char *pem_certificato;
	char *pem_chiave;
	GPtrArray *connessioni;
	GMutex lucchetto;
};

/* ------------------------------------------------------------------ *
 * Chiusura dichiarata (R12)
 *
 * Un client che riceve solo una chiusura di socket mostra «errore di rete» e
 * l'utente non impara niente; il client Android non se ne accorge affatto e
 * resta a fissare l'ultimo fotogramma.
 * ------------------------------------------------------------------ */
static void congeda(freerdp_peer *peer, UINT32 codice, const char *perche)
{
	informazione("congedo il client: %s (0x%04X)", perche, codice);
	freerdp_set_error_info(peer->context->rdp, codice);
	peer->Disconnect(peer);
}

/* ------------------------------------------------------------------ *
 * Contesto del peer
 * ------------------------------------------------------------------ */
static BOOL contesto_nuovo(freerdp_peer *peer, rdpContext *contesto)
{
	ContestoPeer *cp = (ContestoPeer *) contesto;

	cp->vcm = WTSOpenServerA((LPSTR) contesto);
	if (!cp->vcm || cp->vcm == INVALID_HANDLE_VALUE)
	{
		errore("WTSOpenServerA fallita");
		return FALSE;
	}
	cp->evento_stop = CreateEvent(NULL, TRUE, FALSE, NULL);
	cp->id_superficie = 1;
	cp->avvio_us = g_get_monotonic_time();
	return TRUE;
}

static void contesto_libera(freerdp_peer *peer, rdpContext *contesto)
{
	ContestoPeer *cp = (ContestoPeer *) contesto;

	if (!cp)
		return;
	if (cp->gfx)
	{
		if (cp->gfx_aperto)
			cp->gfx->Close(cp->gfx);
		rdpgfx_server_context_free(cp->gfx);
		cp->gfx = NULL;
	}
	g_clear_pointer(&cp->cod, codificatore_libera);
	g_clear_pointer(&cp->immagine, immagine_libera);
	if (cp->evento_stop)
		CloseHandle(cp->evento_stop);
	if (cp->vcm && cp->vcm != INVALID_HANDLE_VALUE)
		WTSCloseServer(cp->vcm);
}

/* ------------------------------------------------------------------ *
 * §3.3 — cosa pretendere dal client, e dirlo quando manca
 * ------------------------------------------------------------------ */
static BOOL peer_capabilities(freerdp_peer *peer)
{
	rdpSettings *imp = peer->context->settings;

	if (!freerdp_settings_get_bool(imp, FreeRDP_SupportGraphicsPipeline))
	{
		avviso("il client non dichiara la pipeline grafica: chiudo");
		congeda(peer, ERRINFO_BAD_CAPABILITIES, "niente EGFX");
		return FALSE;
	}
	if (freerdp_settings_get_uint32(imp, FreeRDP_ColorDepth) != 32)
	{
		avviso("il client non dichiara 32 bpp: chiudo");
		congeda(peer, ERRINFO_BAD_CAPABILITIES, "niente 32 bpp");
		return FALSE;
	}
	if (!freerdp_settings_get_bool(imp, FreeRDP_DesktopResize))
	{
		avviso("il client non sa ridimensionare il desktop: chiudo");
		congeda(peer, ERRINFO_BAD_CAPABILITIES, "niente DesktopResize");
		return FALSE;
	}
	if (freerdp_settings_get_uint32(imp, FreeRDP_PointerCacheSize) == 0)
	{
		avviso("il client non ha cache dei puntatori: chiudo");
		congeda(peer, ERRINFO_BAD_CAPABILITIES, "cache puntatori a zero");
		return FALSE;
	}
	if (!freerdp_settings_get_bool(imp, FreeRDP_FastPathOutput))
	{
		avviso("il client non fa fastpath in uscita: chiudo");
		congeda(peer, ERRINFO_BAD_CAPABILITIES, "niente fastpath");
		return FALSE;
	}
	return TRUE;
}

/*
 * La guardia (R14), e perche' sta QUI e non in peer->Logon.
 *
 * `peer->Logon` sembra il posto giusto e non lo e': FreeRDP lo chiama alla
 * NEGOZIAZIONE, e nel ramo senza NLA gli passa un'identita' VUOTA
 * (`libfreerdp/core/peer.c`, «IFCALLRESULT(TRUE, client->Logon, client,
 * &client->identity, FALSE)»).  Un server che autentica li' non autentica
 * niente — che e' esattamente il difetto da cui R14 nasce, in una forma nuova.
 *
 * Le credenziali del Client Info PDU arrivano allo stato
 * SECURE_SETTINGS_EXCHANGE e finiscono nelle impostazioni; `PostConnect` viene
 * dopo, quindi qui ci sono davvero.  E siccome tornare FALSE da qui chiude la
 * connessione prima dell'attivazione, chi non passa non vede un pixel.
 */
static BOOL peer_post_connect(freerdp_peer *peer)
{
	ContestoPeer *cp = (ContestoPeer *) peer->context;
	rdpSettings *imp = peer->context->settings;
	const char *utente;
	const char *dominio;
	const char *parola;

	/* §3.3 — senza canali dinamici non c'e' EGFX, e senza EGFX non c'e' nulla. */
	if (!WTSVirtualChannelManagerIsChannelJoined(cp->vcm, DRDYNVC_SVC_CHANNEL_NAME))
	{
		avviso("il client non ha aperto il canale DRDYNVC: chiudo");
		congeda(peer, ERRINFO_BAD_CAPABILITIES, "niente DRDYNVC");
		return FALSE;
	}

	if (cp->server->opzioni.senza_autenticazione)
	{
		avviso("autenticazione DISATTIVATA da riga di comando: e' un banco, non un server");
		cp->autenticato = TRUE;
	}
	else
	{
		utente = freerdp_settings_get_string(imp, FreeRDP_Username);
		dominio = freerdp_settings_get_string(imp, FreeRDP_Domain);
		parola = freerdp_settings_get_string(imp, FreeRDP_Password);

		if (!autenticazione_verifica(utente, dominio, parola))
		{
			cp->autenticato = FALSE;
			congeda(peer, ERRINFO_SERVER_DENIED_CONNECTION, "credenziali rifiutate");
			return FALSE;
		}
		cp->autenticato = TRUE;
		informazione("autenticato: %s", utente);
	}

	informazione("client «%s», desktop %ux%u", freerdp_settings_get_string(imp, FreeRDP_ClientHostname)
	                                               ?: "?",
	             freerdp_settings_get_uint32(imp, FreeRDP_DesktopWidth),
	             freerdp_settings_get_uint32(imp, FreeRDP_DesktopHeight));
	return TRUE;
}

/* ------------------------------------------------------------------ *
 * EGFX
 * ------------------------------------------------------------------ */
static UINT32 orario_impacchettato(void)
{
	/* [MS-RDPEGFX] 2.2.2.14: ora<<22 | minuti<<16 | secondi<<10 | millesimi */
	g_autoptr(GDateTime) adesso = g_date_time_new_now_local();
	return ((UINT32) g_date_time_get_hour(adesso) << 22) |
	       ((UINT32) g_date_time_get_minute(adesso) << 16) |
	       ((UINT32) g_date_time_get_second(adesso) << 10) |
	       ((UINT32) (g_date_time_get_microsecond(adesso) / 1000) & 0x3FF);
}

static gboolean prepara_tela(ContestoPeer *cp, gboolean avc_disponibile)
{
	rdpSettings *imp = cp->ctx.settings;
	UINT32 larghezza = freerdp_settings_get_uint32(imp, FreeRDP_DesktopWidth);
	UINT32 altezza = freerdp_settings_get_uint32(imp, FreeRDP_DesktopHeight);
	RDPGFX_RESET_GRAPHICS_PDU reset = { 0 };
	MONITOR_DEF monitor = { 0 };
	RDPGFX_CREATE_SURFACE_PDU crea = { 0 };
	RDPGFX_MAP_SURFACE_TO_OUTPUT_PDU mappa = { 0 };

	cp->immagine = immagine_nuova(larghezza, altezza);
	cp->cod = codificatore_nuovo(avc_disponibile ? CODIFICATORE_AVC420 : CODIFICATORE_PROGRESSIVE,
	                             immagine_larghezza_allineata(cp->immagine),
	                             immagine_altezza_allineata(cp->immagine),
	                             cp->server->opzioni.bitrate_kbit,
	                             cp->server->opzioni.fotogrammi_al_secondo);
	if (!cp->cod)
		return FALSE;

	/* R6 — mai con l'elenco monitor vuoto: mstsc disegna fuori posto.
	 * R5 — il MONITOR_DEF usa bordi INCLUSIVI, al contrario di tutto il resto. */
	monitor.left = 0;
	monitor.top = 0;
	monitor.right = (INT32) larghezza - 1;
	monitor.bottom = (INT32) altezza - 1;
	monitor.flags = MONITOR_PRIMARY;

	reset.width = larghezza;
	reset.height = altezza;
	reset.monitorCount = 1;
	reset.monitorDefArray = &monitor;
	if (cp->gfx->ResetGraphics(cp->gfx, &reset) != CHANNEL_RC_OK)
	{
		errore("ResetGraphics fallita");
		return FALSE;
	}

	/* R1 — creare la superficie e agganciarla all'uscita sono DUE comandi, e
	 * servono entrambi.  FreeRDP e Android disegnano lo stesso anche senza il
	 * secondo; mstsc e RDM no, ed e' costato due giorni il 2 agosto. */
	crea.surfaceId = cp->id_superficie;
	crea.width = (UINT16) immagine_larghezza_allineata(cp->immagine);
	crea.height = (UINT16) immagine_altezza_allineata(cp->immagine);
	crea.pixelFormat = GFX_PIXEL_FORMAT_XRGB_8888;
	if (cp->gfx->CreateSurface(cp->gfx, &crea) != CHANNEL_RC_OK)
	{
		errore("CreateSurface fallita");
		return FALSE;
	}

	mappa.surfaceId = cp->id_superficie;
	mappa.outputOriginX = 0;
	mappa.outputOriginY = 0;
	if (cp->gfx->MapSurfaceToOutput(cp->gfx, &mappa) != CHANNEL_RC_OK)
	{
		errore("MapSurfaceToOutput fallita");
		return FALSE;
	}

	informazione("tela pronta: desktop %ux%u, superficie %ux%u, codec %s", larghezza, altezza,
	             crea.width, crea.height, codificatore_nome(cp->cod));
	cp->gfx_pronto = TRUE;
	return TRUE;
}

static UINT su_caps_advertise(RdpgfxServerContext *gfx, const RDPGFX_CAPS_ADVERTISE_PDU *avviso_pdu)
{
	ContestoPeer *cp = gfx->custom;
	RDPGFX_CAPSET *scelta = NULL;
	UINT32 versione_scelta = 0;
	gboolean avc = FALSE;
	RDPGFX_CAPS_CONFIRM_PDU conferma = { 0 };

	/* R2 — si sceglie la piu' alta che il client dichiara, e si conferma
	 * QUELLA SOLA.  L'elenco e' percorso dall'alto: la prima corrispondenza e'
	 * la migliore. */
	for (gsize v = 0; v < G_N_ELEMENTS(versioni_egfx) && !scelta; v++)
	{
		for (UINT16 i = 0; i < avviso_pdu->capsSetCount; i++)
		{
			if (avviso_pdu->capsSets[i].version == versioni_egfx[v])
			{
				scelta = &avviso_pdu->capsSets[i];
				versione_scelta = versioni_egfx[v];
				break;
			}
		}
	}

	if (!scelta)
	{
		errore("nessuna versione EGFX in comune con il client");
		congeda(cp->ctx.peer, ERRINFO_BAD_CAPABILITIES, "nessuna versione EGFX comune");
		return ERROR_INTERNAL_ERROR;
	}

	/* R3 — la logica dei flag AVC, che decide il codec per tutta la
	 * connessione.  La 10.1 non ha un campo flags valido: li' `flags` vale 0 e
	 * la formula da comunque AVC disponibile, che e' l'esito giusto. */
	if (versione_scelta >= RDPGFX_CAPVERSION_10)
		avc = !(scelta->flags & RDPGFX_CAPS_FLAG_AVC_DISABLED);
	else if (versione_scelta == RDPGFX_CAPVERSION_81)
		avc = !!(scelta->flags & RDPGFX_CAPS_FLAG_AVC420_ENABLED);
	else
		avc = FALSE;

	informazione("EGFX negoziato: versione 0x%08X, flag 0x%02X → AVC %s", versione_scelta,
	             scelta->flags, avc ? "disponibile" : "NON disponibile");

	conferma.capsSet = scelta;
	if (gfx->CapsConfirm(gfx, &conferma) != CHANNEL_RC_OK)
	{
		errore("CapsConfirm fallita");
		return ERROR_INTERNAL_ERROR;
	}

	if (!prepara_tela(cp, avc))
	{
		congeda(cp->ctx.peer, ERRINFO_GRAPHICS_SUBSYSTEM_FAILED, "tela grafica non allestita");
		return ERROR_INTERNAL_ERROR;
	}
	return CHANNEL_RC_OK;
}

static UINT su_frame_acknowledge(RdpgfxServerContext *gfx,
                                 const RDPGFX_FRAME_ACKNOWLEDGE_PDU *riscontro)
{
	ContestoPeer *cp = gfx->custom;

	/* §5 — queueDepth == 0xFFFFFFFF significa «non ti mando piu' riscontri».
	 * Chi aspetta i riscontri per regolare il flusso, e non lo gestisce, si
	 * blocca per sempre. */
	if (riscontro->queueDepth == SUSPEND_FRAME_ACKNOWLEDGEMENT)
	{
		if (!cp->riscontri_sospesi)
			informazione("il client sospende i riscontri: passo al conteggio locale");
		cp->riscontri_sospesi = TRUE;
		g_atomic_int_set(&cp->in_volo, 0);
		return CHANNEL_RC_OK;
	}

	if (g_atomic_int_get(&cp->in_volo) > 0)
		g_atomic_int_dec_and_test(&cp->in_volo);
	traccia("riscontro fotogramma %u, in volo %d", riscontro->frameId,
	        g_atomic_int_get(&cp->in_volo));
	return CHANNEL_RC_OK;
}

static UINT su_cache_import_offer(RdpgfxServerContext *gfx,
                                  const RDPGFX_CACHE_IMPORT_OFFER_PDU *offerta)
{
	/* §5 — va RISPOSTO, anche a vuoto: ignorarlo lascia il client in attesa.
	 * La cache non la usiamo, come nel riferimento. */
	RDPGFX_CACHE_IMPORT_REPLY_PDU risposta = { 0 };
	return gfx->CacheImportReply(gfx, &risposta);
}

static UINT su_qoe_frame_acknowledge(RdpgfxServerContext *gfx,
                                     const RDPGFX_QOE_FRAME_ACKNOWLEDGE_PDU *qoe)
{
	return CHANNEL_RC_OK; /* accettare e ignorare */
}

static gboolean apri_egfx(ContestoPeer *cp)
{
	cp->gfx = rdpgfx_server_context_new(cp->vcm);
	if (!cp->gfx)
	{
		errore("rdpgfx_server_context_new fallita");
		return FALSE;
	}
	cp->gfx->custom = cp;
	cp->gfx->rdpcontext = &cp->ctx;
	cp->gfx->CapsAdvertise = su_caps_advertise;
	cp->gfx->FrameAcknowledge = su_frame_acknowledge;
	cp->gfx->CacheImportOffer = su_cache_import_offer;
	cp->gfx->QoeFrameAcknowledge = su_qoe_frame_acknowledge;

	if (!cp->gfx->Open(cp->gfx))
	{
		errore("apertura del canale EGFX fallita");
		return FALSE;
	}
	cp->gfx_aperto = TRUE;
	diagnostica("canale EGFX aperto, aspetto CapsAdvertise");
	return TRUE;
}

static gboolean manda_fotogramma(ContestoPeer *cp)
{
	RDPGFX_SURFACE_COMMAND cmd = { 0 };
	RDPGFX_START_FRAME_PDU inizio = { 0 };
	RDPGFX_END_FRAME_PDU fine = { 0 };
	gint64 trascorsi;

	if (!cp->gfx_pronto || !cp->autenticato)
		return TRUE;

	/* Controllo di flusso minimo: non si accumulano fotogrammi non riscontrati.
	 * Il regolatore vero, con la soglia ricavata dall'RTT, e' materia di fase 7. */
	if (!cp->riscontri_sospesi && g_atomic_int_get(&cp->in_volo) >= 2)
		return TRUE;

	trascorsi = (g_get_monotonic_time() - cp->avvio_us) / 1000;
	immagine_disegna(cp->immagine, trascorsi);

	cmd.surfaceId = cp->id_superficie;
	cmd.contextId = 0;
	if (!codificatore_comprimi(cp->cod, immagine_pixel(cp->immagine),
	                           immagine_passo(cp->immagine),
	                           immagine_larghezza_allineata(cp->immagine),
	                           immagine_altezza_allineata(cp->immagine),
	                           immagine_larghezza(cp->immagine), immagine_altezza(cp->immagine),
	                           &cmd))
	{
		codificatore_rilascia(cp->cod);
		return TRUE; /* niente di nuovo: non e' un errore */
	}

	inizio.frameId = ++cp->id_fotogramma;
	inizio.timestamp = orario_impacchettato();
	fine.frameId = inizio.frameId;

	if (cp->gfx->SurfaceFrameCommand(cp->gfx, &cmd, &inizio, &fine) != CHANNEL_RC_OK)
	{
		errore("invio del fotogramma fallito");
		codificatore_rilascia(cp->cod);
		return FALSE;
	}
	g_atomic_int_inc(&cp->in_volo);
	codificatore_rilascia(cp->cod);
	traccia("fotogramma %u spedito", inizio.frameId);
	return TRUE;
}

/* ------------------------------------------------------------------ *
 * Il ciclo di una connessione, su un thread suo
 * ------------------------------------------------------------------ */
static gpointer thread_connessione(gpointer dati)
{
	GSocketConnection *connessione = dati;
	GSocket *socket = g_socket_connection_get_socket(connessione);
	Server *server = g_object_get_data(G_OBJECT(connessione), "server");
	freerdp_peer *peer = NULL;
	ContestoPeer *cp = NULL;
	rdpSettings *imp = NULL;
	HANDLE eventi[32] = { 0 };
	HANDLE evento_canale = NULL;
	gint64 prossimo_fotogramma;
	guint32 periodo_ms;
	UINT16 stato_dvc_visto = 0xFFFF;
	gboolean se_ne_va_lui = FALSE;

	peer = freerdp_peer_new(g_socket_get_fd(socket));
	if (!peer)
	{
		errore("freerdp_peer_new fallita");
		goto fine;
	}

	peer->ContextSize = sizeof(ContestoPeer);
	peer->ContextNew = contesto_nuovo;
	peer->ContextFree = contesto_libera;
	if (!freerdp_peer_context_new(peer))
	{
		errore("freerdp_peer_context_new fallita");
		goto fine;
	}

	cp = (ContestoPeer *) peer->context;
	cp->server = server;
	imp = peer->context->settings;

	/* §3.2 — sicurezza: TLS puro, niente NLA.  R13: regge su tutti e tre i
	 * client, e nessuno pretende NLA.  TLS 1.2 va lasciato acceso, perche' RDM
	 * non fa TLS 1.3 e un server solo-1.3 lo escluderebbe. */
	freerdp_settings_set_bool(imp, FreeRDP_RdpSecurity, FALSE);
	freerdp_settings_set_bool(imp, FreeRDP_TlsSecurity, TRUE);
	freerdp_settings_set_bool(imp, FreeRDP_NlaSecurity, FALSE);
	/* 0x0303 e' TLS 1.2 nella numerazione di OpenSSL, che e' quella che
	 * FreeRDP si aspetta qui.  Va lasciato acceso e non alzato a 1.3: RDM non
	 * fa TLS 1.3, e un server solo-1.3 escluderebbe il client Android di
	 * riferimento (R13).  Si scrive il numero invece di tirarsi dentro gli
	 * header di OpenSSL per una costante sola. */
	freerdp_settings_set_uint16(imp, FreeRDP_TLSMinVersion, 0x0303);

	/* Un esemplare NUOVO per ogni connessione: vedi il commento su Server. */
	{
		rdpCertificate *certificato = freerdp_certificate_new_from_pem(server->pem_certificato);
		rdpPrivateKey *chiave = freerdp_key_new_from_pem(server->pem_chiave);

		if (!certificato || !chiave)
		{
			errore("certificato o chiave non ricostruibili per questa connessione");
			freerdp_certificate_free(certificato);
			freerdp_key_free(chiave);
			goto fine;
		}
		freerdp_settings_set_pointer_len(imp, FreeRDP_RdpServerCertificate, certificato, 1);
		freerdp_settings_set_pointer_len(imp, FreeRDP_RdpServerRsaKey, chiave, 1);
	}

	freerdp_settings_set_uint32(imp, FreeRDP_OsMajorType, OSMAJORTYPE_UNIX);
	freerdp_settings_set_uint32(imp, FreeRDP_OsMinorType, OSMINORTYPE_PSEUDO_XSERVER);
	freerdp_settings_set_uint32(imp, FreeRDP_ColorDepth, 32);

	/* Accendere SupportGraphicsPipeline fa due cose: dichiara EGFX nelle
	 * capacita' E accende DYNVC_GFX_PROTOCOL_SUPPORTED nella risposta di
	 * negoziazione X.224 (§3.1).  L'altra bandiera richiesta,
	 * EXTENDED_CLIENT_DATA_SUPPORTED, FreeRDP la mette sempre. */
	freerdp_settings_set_bool(imp, FreeRDP_SupportGraphicsPipeline, TRUE);
	freerdp_settings_set_bool(imp, FreeRDP_GfxAVC444v2, FALSE);
	freerdp_settings_set_bool(imp, FreeRDP_GfxAVC444, FALSE);
	freerdp_settings_set_bool(imp, FreeRDP_GfxH264, FALSE); /* si accende al CapsAdvertise */
	freerdp_settings_set_bool(imp, FreeRDP_GfxSmallCache, FALSE);
	freerdp_settings_set_bool(imp, FreeRDP_GfxThinClient, FALSE);

	freerdp_settings_set_bool(imp, FreeRDP_SurfaceFrameMarkerEnabled, TRUE);
	freerdp_settings_set_bool(imp, FreeRDP_FrameMarkerCommandEnabled, TRUE);
	freerdp_settings_set_uint32(imp, FreeRDP_PointerCacheSize, 100);
	freerdp_settings_set_bool(imp, FreeRDP_FastPathOutput, TRUE);
	freerdp_settings_set_bool(imp, FreeRDP_NetworkAutoDetect, TRUE);
	freerdp_settings_set_bool(imp, FreeRDP_RefreshRect, FALSE);
	freerdp_settings_set_bool(imp, FreeRDP_SupportMultitransport, FALSE); /* niente UDP */
	freerdp_settings_set_uint32(imp, FreeRDP_VCFlags, VCCAPS_COMPR_SC);
	freerdp_settings_set_uint32(imp, FreeRDP_VCChunkSize, 16256);
	freerdp_settings_set_bool(imp, FreeRDP_HasExtendedMouseEvent, TRUE);
	freerdp_settings_set_bool(imp, FreeRDP_HasHorizontalWheel, TRUE);
	freerdp_settings_set_bool(imp, FreeRDP_HasRelativeMouseEvent, TRUE);
	freerdp_settings_set_bool(imp, FreeRDP_UnicodeInput, TRUE);

	peer->Capabilities = peer_capabilities;
	peer->PostConnect = peer_post_connect;

	if (!peer->Initialize(peer))
	{
		errore("inizializzazione del peer fallita");
		goto fine;
	}

	informazione("connessione da %s", peer->hostname ? peer->hostname : "?");

	evento_canale = WTSVirtualChannelManagerGetEventHandle(cp->vcm);
	periodo_ms = 1000 / MAX(1u, server->opzioni.fotogrammi_al_secondo);
	prossimo_fotogramma = g_get_monotonic_time() + periodo_ms * 1000;

	while (TRUE)
	{
		guint32 n = 0;
		guint32 n_freerdp;
		gint64 adesso;
		DWORD attesa;

		eventi[n++] = cp->evento_stop;
		eventi[n++] = evento_canale;
		n_freerdp = peer->GetEventHandles(peer, &eventi[n], 32 - n);
		if (!n_freerdp)
		{
			avviso("nessun descrittore dal peer: chiudo");
			break;
		}
		n += n_freerdp;

		adesso = g_get_monotonic_time();
		attesa = prossimo_fotogramma > adesso ? (DWORD) ((prossimo_fotogramma - adesso) / 1000) : 0;
		WaitForMultipleObjects(n, eventi, FALSE, attesa);

		if (WaitForSingleObject(cp->evento_stop, 0) == WAIT_OBJECT_0)
			break;

		if (!peer->CheckFileDescriptor(peer))
		{
			/* Se ne va lui: il codice d'errore lo ha gia' messo FreeRDP, e
			 * sovrascriverlo sarebbe una bugia oltre che inutile. */
			informazione("il client se n'e' andato");
			se_ne_va_lui = TRUE;
			break;
		}

		if (peer->connected && WTSVirtualChannelManagerIsChannelJoined(cp->vcm, DRDYNVC_SVC_CHANNEL_NAME))
		{
			UINT16 stato = WTSVirtualChannelManagerGetDrdynvcState(cp->vcm);

			if (stato != stato_dvc_visto)
			{
				diagnostica("stato di drdynvc: %u", stato);
				stato_dvc_visto = stato;
			}
			switch (stato)
			{
				case DRDYNVC_STATE_NONE:
					/* Serve a far chiamare WTSVirtualChannelManagerCheckFileDescriptor,
					 * che e' cio' che inizializza drdynvc. */
					SetEvent(evento_canale);
					break;
				case DRDYNVC_STATE_READY:
					if (!cp->gfx_aperto && !apri_egfx(cp))
					{
						congeda(peer, ERRINFO_GRAPHICS_SUBSYSTEM_FAILED, "EGFX non apribile");
						goto chiudi;
					}
					break;
				default:
					break;
			}
		}

		/* Solo quando l'evento e' segnalato, come nel riferimento: chiamarla a
		 * ogni giro non fa avanzare la macchina a stati di drdynvc. */
		if (WaitForSingleObject(evento_canale, 0) == WAIT_OBJECT_0 &&
		    !WTSVirtualChannelManagerCheckFileDescriptor(cp->vcm))
		{
			avviso("il gestore dei canali virtuali si e' chiuso");
			break;
		}

		adesso = g_get_monotonic_time();
		if (adesso >= prossimo_fotogramma)
		{
			prossimo_fotogramma = adesso + periodo_ms * 1000;
			if (!manda_fotogramma(cp))
			{
				congeda(peer, ERRINFO_GRAPHICS_SUBSYSTEM_FAILED, "invio del fotogramma fallito");
				goto chiudi;
			}
		}
	}

chiudi:
	/* R12 — il congedo si dichiara solo quando a chiudere siamo noi. */
	if (peer->connected && !se_ne_va_lui)
		congeda(peer, ERRINFO_RPC_INITIATED_DISCONNECT, "chiusura del server");
	peer->Close(peer);

fine:
	if (peer)
	{
		freerdp_peer_context_free(peer);
		freerdp_peer_free(peer);
	}
	if (server)
	{
		g_mutex_lock(&server->lucchetto);
		g_ptr_array_remove_fast(server->connessioni, connessione);
		g_mutex_unlock(&server->lucchetto);
	}
	informazione("connessione conclusa");
	g_object_unref(connessione);
	return NULL;
}

static gboolean su_connessione(GSocketService *servizio, GSocketConnection *connessione,
                               GObject *sorgente, gpointer dati)
{
	Server *server = dati;
	GThread *thread;

	g_object_ref(connessione);
	g_object_set_data(G_OBJECT(connessione), "server", server);

	g_mutex_lock(&server->lucchetto);
	g_ptr_array_add(server->connessioni, connessione);
	g_mutex_unlock(&server->lucchetto);

	thread = g_thread_new("remotix-peer", thread_connessione, connessione);
	g_thread_unref(thread);
	return TRUE;
}

/* ------------------------------------------------------------------ *
 * Certificato
 * ------------------------------------------------------------------ */
static gboolean genera_certificato(const char *cert, const char *chiave, GError **sbaglio)
{
	g_autofree char *comando = NULL;
	int stato = 0;

	informazione("genero un certificato autofirmato in %s", cert);
	comando = g_strdup_printf(
	    "openssl req -x509 -newkey rsa:2048 -nodes -keyout '%s' -out '%s' -days 3650 -subj '/CN=remotix'",
	    chiave, cert);
	if (!g_spawn_command_line_sync(comando, NULL, NULL, &stato, sbaglio))
		return FALSE;
	if (stato != 0)
	{
		g_set_error(sbaglio, G_IO_ERROR, G_IO_ERROR_FAILED, "openssl e' uscito con stato %d", stato);
		return FALSE;
	}
	g_chmod(chiave, 0600);
	return TRUE;
}

static gboolean carica_certificato(Server *server, GError **sbaglio)
{
	g_autofree char *pem_cert = NULL;
	g_autofree char *pem_chiave = NULL;

	if (!g_file_test(server->opzioni.certificato, G_FILE_TEST_EXISTS) ||
	    !g_file_test(server->opzioni.chiave, G_FILE_TEST_EXISTS))
	{
		if (!genera_certificato(server->opzioni.certificato, server->opzioni.chiave, sbaglio))
			return FALSE;
	}

	if (!g_file_get_contents(server->opzioni.certificato, &pem_cert, NULL, sbaglio))
		return FALSE;
	if (!g_file_get_contents(server->opzioni.chiave, &pem_chiave, NULL, sbaglio))
		return FALSE;

	/* Si verifica SUBITO che siano leggibili, cosi' un certificato guasto si
	 * manifesta all'avvio e non alla prima connessione. */
	{
		rdpCertificate *prova_cert = freerdp_certificate_new_from_pem(pem_cert);
		rdpPrivateKey *prova_chiave = freerdp_key_new_from_pem(pem_chiave);
		gboolean buoni = prova_cert && prova_chiave;

		freerdp_certificate_free(prova_cert);
		freerdp_key_free(prova_chiave);
		if (!buoni)
		{
			g_set_error(sbaglio, G_IO_ERROR, G_IO_ERROR_FAILED,
			            "certificato o chiave non leggibili (%s, %s)",
			            server->opzioni.certificato, server->opzioni.chiave);
			return FALSE;
		}
	}

	server->pem_certificato = g_steal_pointer(&pem_cert);
	server->pem_chiave = g_steal_pointer(&pem_chiave);
	return TRUE;
}

/* ------------------------------------------------------------------ *
 * Ciclo di vita
 * ------------------------------------------------------------------ */
Server *server_nuovo(const OpzioniServer *opzioni, GError **sbaglio)
{
	Server *server = g_new0(Server, 1);

	server->opzioni = *opzioni;
	server->opzioni.indirizzo = g_strdup(opzioni->indirizzo);
	server->opzioni.certificato = g_strdup(opzioni->certificato);
	server->opzioni.chiave = g_strdup(opzioni->chiave);
	server->connessioni = g_ptr_array_new();
	g_mutex_init(&server->lucchetto);

	winpr_InitializeSSL(WINPR_SSL_INIT_DEFAULT);

	/*
	 * Va fatto UNA VOLTA, prima di qualunque WTSOpenServerA.
	 *
	 * Senza, WinPR non sa che la sua API WTS la implementa FreeRDP e ripiega
	 * sugli stub di FreeRDS: prova a caricare `libfreerds-fdsapi.so`, non la
	 * trova, e `WTSOpenServerA` restituisce NULL.  Il sintomo non nomina la
	 * causa — «failed to parse freerds.instance» — e la connessione muore
	 * prima di esistere.  Lo chiamano tutti i server di FreeRDP (shadow, proxy,
	 * sample) e anche gnome-remote-desktop.
	 */
	WTSRegisterWtsApiFunctionTable(FreeRDP_InitWtsApi());

	if (!carica_certificato(server, sbaglio))
	{
		server_libera(server);
		return NULL;
	}
	return server;
}

gboolean server_avvia(Server *server, GError **sbaglio)
{
	server->servizio = g_socket_service_new();

	if (server->opzioni.indirizzo)
	{
		g_autoptr(GInetAddress) indirizzo =
		    g_inet_address_new_from_string(server->opzioni.indirizzo);
		g_autoptr(GSocketAddress) sa = NULL;

		if (!indirizzo)
		{
			g_set_error(sbaglio, G_IO_ERROR, G_IO_ERROR_INVALID_ARGUMENT,
			            "indirizzo non valido: %s", server->opzioni.indirizzo);
			return FALSE;
		}
		sa = g_inet_socket_address_new(indirizzo, server->opzioni.porta);
		if (!g_socket_listener_add_address(G_SOCKET_LISTENER(server->servizio), sa,
		                                   G_SOCKET_TYPE_STREAM, G_SOCKET_PROTOCOL_TCP, NULL, NULL,
		                                   sbaglio))
			return FALSE;
	}
	else if (!g_socket_listener_add_inet_port(G_SOCKET_LISTENER(server->servizio),
	                                          server->opzioni.porta, NULL, sbaglio))
	{
		return FALSE;
	}

	g_signal_connect(server->servizio, "incoming", G_CALLBACK(su_connessione), server);
	g_socket_service_start(server->servizio);

	informazione("in ascolto su %s:%u", server->opzioni.indirizzo ?: "*", server->opzioni.porta);
	return TRUE;
}

void server_ferma(Server *server)
{
	if (!server)
		return;
	if (server->servizio)
	{
		g_socket_service_stop(server->servizio);
		g_socket_listener_close(G_SOCKET_LISTENER(server->servizio));
	}
}

void server_libera(Server *server)
{
	if (!server)
		return;
	server_ferma(server);
	g_clear_object(&server->servizio);
	g_clear_pointer(&server->pem_certificato, g_free);
	g_clear_pointer(&server->pem_chiave, g_free);
	if (server->connessioni)
		g_ptr_array_free(server->connessioni, TRUE);
	g_mutex_clear(&server->lucchetto);
	g_free(server->opzioni.indirizzo);
	g_free(server->opzioni.certificato);
	g_free(server->opzioni.chiave);
	g_free(server);
}
