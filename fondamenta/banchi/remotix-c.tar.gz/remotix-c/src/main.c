/*
 * REMOTIX — server RDP per Linux.
 *
 * Questo file e' lo scheletro della fase 1: opzioni, registro, segnali e
 * uscita pulita.  Non parla ancora RDP; la fase 2 gli mette dentro il peer
 * FreeRDP e la pipeline EGFX.
 *
 * ⛔ Prima di toccare qualunque cosa che riguardi il protocollo, si legge
 *    REFERENCE.md — e' regola vincolante (§7.0 di SPECIFICA.md).  Le
 *    incompatibilita' raccolte li' non si manifestano come errori: si
 *    manifestano come schermo nero su un client su tre.
 */
#include <freerdp/freerdp.h>
#include <glib.h>
#include <glib-unix.h>
#include <stdlib.h>

#include "autenticazione.h"
#include "registro.h"
#include "server.h"

typedef struct
{
	GMainLoop *ciclo;
	Server *server;
	int uscita;
} Remotix;

static gint porta = 3389;
static gchar *indirizzo = NULL;
static gchar *nome_livello = NULL;
static gchar *certificato = NULL;
static gchar *chiave = NULL;
static gint bitrate = 10000;
static gint fotogrammi = 30;
static gboolean senza_autenticazione = FALSE;
static gboolean mostra_versione = FALSE;

static GOptionEntry opzioni[] = {
	{ "porta", 'p', 0, G_OPTION_ARG_INT, &porta, "Porta su cui ascoltare (predefinita: 3389)",
	  "NUMERO" },
	{ "indirizzo", 'a', 0, G_OPTION_ARG_STRING, &indirizzo,
	  "Indirizzo su cui ascoltare (predefinito: tutti)", "IND" },
	{ "registro", 'r', 0, G_OPTION_ARG_STRING, &nome_livello, "Livello del registro", "LIVELLO" },
	{ "certificato", 0, 0, G_OPTION_ARG_FILENAME, &certificato,
	  "Certificato TLS in PEM (se manca, se ne genera uno)", "FILE" },
	{ "chiave", 0, 0, G_OPTION_ARG_FILENAME, &chiave, "Chiave privata TLS in PEM", "FILE" },
	{ "bitrate", 0, 0, G_OPTION_ARG_INT, &bitrate, "Bitrate video in kbit/s (predefinito: 10000)",
	  "KBIT" },
	{ "fotogrammi", 0, 0, G_OPTION_ARG_INT, &fotogrammi,
	  "Fotogrammi al secondo (predefinito: 30)", "N" },
	{ "senza-autenticazione", 0, 0, G_OPTION_ARG_NONE, &senza_autenticazione,
	  "NON autentica nessuno: solo per il banco di prova", NULL },
	{ "versione", 'V', 0, G_OPTION_ARG_NONE, &mostra_versione, "Mostra la versione ed esce", NULL },
	/* Le opzioni del progetto sono in italiano come tutto il resto, ma
	 * «--version» e' quello che chiunque prova per primo, e PIANO.md lo indica
	 * come la prova visibile della fase 1: si accetta anche quello. */
	{ "version", 0, G_OPTION_FLAG_HIDDEN, G_OPTION_ARG_NONE, &mostra_versione, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL, NULL },
};

static void stampa_versione(void)
{
	g_print("REMOTIX %s\n", PACCHETTO_VERSIONE);
	g_print("  FreeRDP   %s (%s)\n", freerdp_get_version_string(), freerdp_get_build_revision());
	g_print("  GLib      %u.%u.%u\n", glib_major_version, glib_minor_version, glib_micro_version);
}

/*
 * I due segnali di arresto.
 *
 * g_unix_signal_add non esegue nulla dentro il gestore di segnale vero: mette
 * in coda una sorgente sul ciclo principale, che viene servita fra un giro e
 * l'altro.  Serve perche' qui dentro, piu' avanti, ci sara' da smontare
 * sessioni e rilasciare tasti rimasti premuti (R6 di REFERENCE.md §6.1): cose
 * che in un gestore di segnale asincrono non si possono fare.
 */
static gboolean su_arresto(gpointer dati)
{
	Remotix *remotix = dati;

	informazione("arresto richiesto, chiudo");
	g_main_loop_quit(remotix->ciclo);
	return G_SOURCE_REMOVE;
}

int main(int argc, char **argv)
{
	Remotix remotix = { .uscita = EXIT_SUCCESS };
	LivelloRegistro livello = REGISTRO_INFORMAZIONE;
	g_autoptr(GError) sbaglio = NULL;
	g_autoptr(GOptionContext) contesto = NULL;

	contesto = g_option_context_new("- server RDP per Linux");
	g_option_context_add_main_entries(contesto, opzioni, NULL);
	{
		g_autofree char *coda =
		    g_strdup_printf("Livelli del registro: %s.", registro_nomi_livelli());
		g_option_context_set_description(contesto, coda);
	}

	if (!g_option_context_parse(contesto, &argc, &argv, &sbaglio))
	{
		g_printerr("%s\n", sbaglio->message);
		return EXIT_FAILURE;
	}

	if (mostra_versione)
	{
		stampa_versione();
		return EXIT_SUCCESS;
	}

	/* Il livello si accetta anche dall'ambiente, che e' comodo quando il server
	 * lo avvia un'unita' systemd e la riga di comando non si tocca. */
	const char *dall_ambiente = g_getenv("REMOTIX_REGISTRO");
	const char *scelto = nome_livello ? nome_livello : dall_ambiente;
	if (scelto && !registro_livello_da_nome(scelto, &livello))
	{
		g_printerr("livello di registro sconosciuto: «%s»\nQuelli accettati sono: %s.\n", scelto,
		           registro_nomi_livelli());
		return EXIT_FAILURE;
	}

	registro_avvia(livello);

	if (porta < 1 || porta > 65535)
	{
		errore("porta fuori intervallo: %d", porta);
		return EXIT_FAILURE;
	}

	informazione("REMOTIX %s — FreeRDP %s", PACCHETTO_VERSIONE, freerdp_get_version_string());
	diagnostica("livello del registro: %s", scelto ? scelto : "informazione");

	/* §3.4 — un server che non sa di chi sia la sessione che serve non deve
	 * aprire la porta.  Si dichiara all'avvio, perche' su ogni rifiuto si
	 * scriveranno tutti e due i nomi. */
	if (!senza_autenticazione)
	{
		const char *atteso = autenticazione_utente_atteso();
		if (!atteso)
		{
			errore("non riesco a stabilire di quale utente e' la sessione: non parto");
			return EXIT_FAILURE;
		}
		informazione("servo la sessione di «%s»", atteso);
	}

	{
		g_autofree char *cert_predefinito = NULL;
		g_autofree char *chiave_predefinita = NULL;
		OpzioniServer opzioni = { 0 };

		if (!certificato || !chiave)
		{
			g_autofree char *cartella =
			    g_build_filename(g_get_user_data_dir(), "remotix", NULL);
			g_mkdir_with_parents(cartella, 0700);
			cert_predefinito = g_build_filename(cartella, "certificato.pem", NULL);
			chiave_predefinita = g_build_filename(cartella, "chiave.pem", NULL);
		}

		opzioni.porta = (uint16_t) porta;
		opzioni.indirizzo = indirizzo;
		opzioni.certificato = certificato ?: cert_predefinito;
		opzioni.chiave = chiave ?: chiave_predefinita;
		opzioni.bitrate_kbit = (uint32_t) MAX(100, bitrate);
		opzioni.fotogrammi_al_secondo = (uint32_t) CLAMP(fotogrammi, 1, 120);
		opzioni.senza_autenticazione = senza_autenticazione;

		remotix.server = server_nuovo(&opzioni, &sbaglio);
		if (!remotix.server)
		{
			errore("%s", sbaglio->message);
			return EXIT_FAILURE;
		}
		if (!server_avvia(remotix.server, &sbaglio))
		{
			errore("%s", sbaglio->message);
			server_libera(remotix.server);
			return EXIT_FAILURE;
		}
	}

	remotix.ciclo = g_main_loop_new(NULL, FALSE);
	g_unix_signal_add(SIGINT, su_arresto, &remotix);
	g_unix_signal_add(SIGTERM, su_arresto, &remotix);

	g_main_loop_run(remotix.ciclo);

	server_libera(remotix.server);

	/* L'uscita e' esplicita e ordinata: e' l'abitudine che in fase 5 diventera'
	 * lo smontaggio del palco e il congedo dichiarato al client (R12). */
	g_main_loop_unref(remotix.ciclo);
	g_free(indirizzo);
	g_free(certificato);
	g_free(chiave);
	g_free(nome_livello);
	informazione("chiuso");
	return remotix.uscita;
}
