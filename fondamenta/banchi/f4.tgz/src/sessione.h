/*
 * sessione — la sessione grafica: REMOTIX la avvia, non si limita a trovarla.
 *
 * Perche' (§5.9-bis di SPECIFICA.md): dopo un «Esci» dal menu di sistema non
 * c'e' piu' niente da mostrare, e al primo avvio della macchina non c'e' alcun
 * gestore di accesso grafico che apra una sessione — e non deve esserci, ne
 * aprirebbe una LOCALE che confligge con le regole di §3.4.
 *
 * Due regole pagate care, entrambe codificate qui:
 *
 *   - L'AMBIENTE SI COMPONE, NON SI EREDITA.  Chi avvia la sessione le regala
 *     tutto il proprio ambiente, comprese le variabili che non c'entrano
 *     nulla, e da li' la sessione lo ridistribuisce al gestore systemd
 *     dell'utente e all'attivazione D-Bus, dove SOPRAVVIVE al compositore.  Una
 *     `LC_ALL=C` arrivata per sbaglio da una shell SSH ha impedito a TUTTE le
 *     applicazioni di aprirsi, e il sintomo non diceva «manca una variabile»:
 *     diceva «le applicazioni non partono».
 *   - LA VITALITA' SI ACCERTA SENZA INTERPRETARE LA RISPOSTA.  Si guarda solo
 *     che la risposta ARRIVI.  Dichiarare il tipo di ritorno di
 *     `GetCurrentState` significa che la vitalita' della sessione dipende
 *     dall'esattezza di quella dichiarazione, e la prima stesura in Rust
 *     falliva cosi': la sessione era partita e REMOTIX la dava per morta.
 *     Anche `Ping` e `Introspect` non valgono, perche' rispondono pure a ciclo
 *     principale fermo: li serve la libreria D-Bus per conto proprio (§5.6).
 */
#pragma once

#include <glib.h>

/* Come si avvia una sessione GNOME senza monitor.  Che la Shell parta senza
 * schermo lo decide la sovrascrittura dell'ExecStart della sua unita', che e'
 * configurazione della macchina: sta in `provision-vm.sh` e apparterra' al
 * confezionamento della fase 11. */
#define SESSIONE_COMANDO_PREDEFINITO "exec gnome-session --session=gnome"

/* Vero se c'e' un compositore che risponde. */
gboolean sessione_viva(void);

/* Si assicura che ci sia una sessione grafica, avviandola se manca.
 * `avviata` (facoltativo) dice se l'ha dovuta avviare. */
gboolean sessione_assicura(const char *comando, gboolean *avviata, GError **sbaglio);
