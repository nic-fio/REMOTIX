/*
 * server — accettazione delle connessioni e ciclo di una sessione RDP.
 *
 * Le connessioni si accettano con un GSocketService, cioe' in parallelo per
 * costruzione, e ciascuna viene servita da un thread suo (e' la struttura del
 * riferimento, §3 di gnome-remote-desktop.md).
 */
#pragma once

#include <glib.h>
#include <stdint.h>

typedef struct Server Server;

typedef struct
{
	uint16_t porta;
	char *indirizzo;   /* NULL = tutti */
	char *certificato; /* percorso PEM; se manca, se ne genera uno */
	char *chiave;
	uint32_t bitrate_kbit;
	uint32_t fotogrammi_al_secondo;
	gboolean senza_autenticazione; /* solo per il banco: salta PAM */
	/*
	 * Manda la scena sintetica invece del desktop vero.
	 *
	 * Non e' un residuo della fase 2: e' lo strumento che isola il protocollo
	 * dalla cattura.  Se qualcosa non si vede, con questa accesa il sospetto
	 * cade su una cosa sola — ed e' la lezione di §5.4 di SPECIFICA.md.  Serve
	 * anche a provare la pipeline dove una sessione grafica non c'e' affatto,
	 * per esempio nel contenitore di sviluppo.
	 */
	gboolean immagine_di_prova;
	/* Come si avvia la sessione grafica, se manca.  NULL = il predefinito. */
	char *comando_sessione;
} OpzioniServer;

Server *server_nuovo(const OpzioniServer *opzioni, GError **sbaglio);
gboolean server_avvia(Server *server, GError **sbaglio);
void server_ferma(Server *server);
void server_libera(Server *server);
