#include "palco.h"

#include <gio/gio.h>
#include <string.h>

#include "cattura.h"
#include "mutter.h"
#include "registro.h"
#include "sessione.h"
#include "suono.h"

/* Quanto silenzio basta per dire che il desktop ha finito di ridisegnarsi. */
#define QUIETE_RIDISEGNO_MS 300
/* Quanti fotogrammi servono prima di fidarsi del silenzio (R10). */
#define FOTOGRAMMI_PRIMA_DI_FIDARSI 2
/* E quanto si e' disposti ad aspettare in tutto, perche' un desktop che cambia
 * di continuo non tenga fermo il primo fotogramma all'infinito. */
#define ATTESA_RIDISEGNO_MS 2500

struct Palco
{
	/* Due lucchetti, con due compiti distinti: `montaggio` serializza chi monta
	 * e smonta — piu' connessioni possono chiederlo insieme — e `lucchetto`
	 * protegge il solo fotogramma, che e' l'unica cosa toccata dal thread di
	 * PipeWire.  Tenerne uno solo significherebbe che una connessione che monta
	 * blocca la cattura di quella che sta gia' disegnando. */
	GMutex montaggio;
	GMutex lucchetto;
	GCond novita;
	/* Chi usa l'input lo tiene in lettura; chi lo smonta lo prende in
	 * scrittura, e cosi' non lo si libera sotto i piedi di nessuno. */
	GRWLock uso_input;
	/* E lo stesso per il suono, per la stessa ragione: la connessione accende e
	 * spegne la cattura audio mentre la sessione puo' finire in qualunque
	 * momento. */
	GRWLock uso_suono;
	/* E per gli appunti, che oltre a tutto questo hanno un thread proprio. */
	GRWLock uso_appunti;

	MutterSessione *mutter;
	Cattura *cattura;
	Input *input;
	Suono *suono;
	Appunti *appunti;

	/* La misura chiesta, cioe' quella del palco montato. */
	uint32_t larghezza, altezza;

	/* L'ultimo fotogramma, e nient'altro: di una raffica conta l'ultimo. */
	uint8_t *ultimo;
	gsize capienza;
	uint32_t passo, larghezza_arrivata, altezza_arrivata;
	guint64 generazione;

	gboolean finita;
	gboolean misura_segnalata;
};

/* ------------------------------------------------------------------ *
 * Le due richiamate, chiamate DAL THREAD DI PIPEWIRE
 * ------------------------------------------------------------------ */
static void su_fotogramma(const uint8_t *pixel, uint32_t passo, uint32_t larghezza,
                          uint32_t altezza, gpointer dati)
{
	Palco *palco = dati;
	gsize servono = (gsize) passo * altezza;

	g_mutex_lock(&palco->lucchetto);
	if (palco->capienza < servono)
	{
		g_free(palco->ultimo);
		palco->ultimo = g_malloc(servono);
		palco->capienza = servono;
	}
	memcpy(palco->ultimo, pixel, servono);
	palco->passo = passo;
	palco->larghezza_arrivata = larghezza;
	palco->altezza_arrivata = altezza;
	palco->generazione++;
	g_cond_broadcast(&palco->novita);
	g_mutex_unlock(&palco->lucchetto);
}

static void su_fine(gpointer dati)
{
	Palco *palco = dati;

	/*
	 * Qui si segna e basta.  Chiamare `cattura_ferma` da dentro una richiamata
	 * di PipeWire significherebbe fermare il ciclo da dentro il ciclo: si
	 * smonta dal thread della connessione, che se ne accorge al giro dopo.
	 */
	g_mutex_lock(&palco->lucchetto);
	palco->finita = TRUE;
	g_cond_broadcast(&palco->novita);
	g_mutex_unlock(&palco->lucchetto);
}

/* ------------------------------------------------------------------ *
 * Ciclo di vita
 * ------------------------------------------------------------------ */
Palco *palco_nuovo(void)
{
	Palco *palco = g_new0(Palco, 1);

	g_mutex_init(&palco->montaggio);
	g_mutex_init(&palco->lucchetto);
	g_cond_init(&palco->novita);
	g_rw_lock_init(&palco->uso_input);
	g_rw_lock_init(&palco->uso_suono);
	g_rw_lock_init(&palco->uso_appunti);
	return palco;
}

/* Va chiamata con `montaggio` preso e `lucchetto` LIBERO: `cattura_ferma`
 * aspetta il thread di PipeWire, che potrebbe essere fermo proprio sul
 * lucchetto dentro `su_fotogramma`. */
static void smonta_interno(Palco *palco)
{
	/*
	 * L'input per primo: i suoi dispositivi virtuali appartengono alla sessione
	 * di controllo, e chiuderla sotto di lui lo lascerebbe a parlare nel vuoto.
	 *
	 * Si ferma tenendo il lucchetto in SCRITTURA, cioe' aspettando che nessuna
	 * connessione lo stia usando: fermarlo mentre qualcuno vi accoda un tasto
	 * gli libera la coda sotto le mani.
	 */
	g_rw_lock_writer_lock(&palco->uso_input);
	g_clear_pointer(&palco->input, input_ferma);
	g_rw_lock_writer_unlock(&palco->uso_input);

	/*
	 * Il suono si chiude tenendo il suo lucchetto in SCRITTURA, cioe'
	 * aspettando che nessuna connessione stia accendendo o spegnendo la propria
	 * cattura.  Da qui in poi chi chiede il suono trova NULL — ed e' il motivo
	 * per cui il puntatore non si tiene da parte, ma si richiede ogni volta.
	 */
	g_rw_lock_writer_lock(&palco->uso_suono);
	g_clear_pointer(&palco->suono, suono_chiudi);
	g_rw_lock_writer_unlock(&palco->uso_suono);

	/*
	 * Gli appunti prima della sessione di controllo che li ospita: sono metodi
	 * di QUELLA sessione, e chiuderla sotto di loro li lascerebbe a parlare con
	 * un oggetto che non esiste piu'.
	 */
	g_rw_lock_writer_lock(&palco->uso_appunti);
	g_clear_pointer(&palco->appunti, appunti_chiudi);
	g_rw_lock_writer_unlock(&palco->uso_appunti);

	g_clear_pointer(&palco->cattura, cattura_ferma);
	g_clear_pointer(&palco->mutter, mutter_chiudi);

	g_mutex_lock(&palco->lucchetto);
	palco->larghezza = palco->altezza = 0;
	palco->finita = FALSE;
	palco->misura_segnalata = FALSE;
	/*
	 * La generazione NON si azzera, e non e' un dettaglio: un'altra connessione
	 * puo' essere in corso e avere gia' visto il fotogramma numero 500.
	 * Ripartendo da zero, per lei nulla sarebbe piu' «nuovo» e resterebbe ferma
	 * sull'immagine di prima per sempre — un difetto che si presenterebbe solo
	 * con due client sovrapposti, cioe' a intermittenza e mai a comando.
	 */
	g_mutex_unlock(&palco->lucchetto);
}

void palco_smonta(Palco *palco)
{
	if (!palco)
		return;
	g_mutex_lock(&palco->montaggio);
	if (palco->mutter)
	{
		smonta_interno(palco);
		informazione("palco smontato");
	}
	g_mutex_unlock(&palco->montaggio);
}

void palco_libera(Palco *palco)
{
	if (!palco)
		return;
	palco_smonta(palco);
	g_free(palco->ultimo);
	g_rw_lock_clear(&palco->uso_appunti);
	g_rw_lock_clear(&palco->uso_suono);
	g_rw_lock_clear(&palco->uso_input);
	g_cond_clear(&palco->novita);
	g_mutex_clear(&palco->lucchetto);
	g_mutex_clear(&palco->montaggio);
	g_free(palco);
}

/*
 * Aspetta che il desktop si sia RIDISEGNATO alla misura nuova (R10).
 *
 * Si raccolgono i fotogrammi finche' non smettono di arrivare, e ci si fida del
 * silenzio solo dopo il secondo: il primo dopo un cambio di misura e' quello
 * vuoto, e il silenzio fra lui e quello buono e' la trappola.
 */
static void stabilizza(Palco *palco)
{
	gint64 scadenza = g_get_monotonic_time() + (gint64) ATTESA_RIDISEGNO_MS * 1000;
	guint raccolti = 0;
	guint64 vista;

	g_mutex_lock(&palco->lucchetto);
	vista = palco->generazione;
	while (g_get_monotonic_time() < scadenza)
	{
		gint64 fine_quiete = g_get_monotonic_time() + (gint64) QUIETE_RIDISEGNO_MS * 1000;

		if (!g_cond_wait_until(&palco->novita, &palco->lucchetto, fine_quiete))
		{
			/* Silenzio. */
			if (raccolti >= FOTOGRAMMI_PRIMA_DI_FIDARSI)
				break;
			continue;
		}
		if (palco->finita)
			break;
		if (palco->generazione > vista)
		{
			raccolti += (guint) (palco->generazione - vista);
			vista = palco->generazione;
		}
	}
	g_mutex_unlock(&palco->lucchetto);

	diagnostica("atteso il ridisegno alla misura nuova: %u fotogrammi raccolti", raccolti);
}

/* Va chiamata con `montaggio` preso e con NULLA di montato. */
static gboolean monta_interno(Palco *palco, uint32_t larghezza, uint32_t altezza,
                              uint32_t fotogrammi_al_secondo, GError **sbaglio)
{
	uint32_t negoziata_l = 0, negoziata_a = 0;

	palco->mutter = mutter_apri(sbaglio);
	if (!palco->mutter)
		return FALSE;

	palco->cattura = cattura_avvia(mutter_nodo(palco->mutter), larghezza, altezza,
	                               fotogrammi_al_secondo, su_fotogramma, su_fine, palco, sbaglio);
	if (!palco->cattura)
	{
		g_clear_pointer(&palco->mutter, mutter_chiudi);
		return FALSE;
	}

	/*
	 * Se Mutter ha negoziato una misura diversa da quella chiesta, lo si dice
	 * FORTE e subito.  Il sintomo altrimenti sarebbe un desktop che copre solo
	 * una parte della superficie — e quel sintomo, quando comparve il 3 agosto,
	 * costo' una caccia che finì in una questione aperta.
	 */
	cattura_misura_negoziata(palco->cattura, &negoziata_l, &negoziata_a);
	if (negoziata_l && (negoziata_l != larghezza || negoziata_a != altezza))
		errore("Mutter ha negoziato %ux%u invece dei %ux%u chiesti: il desktop non coprira' "
		       "tutta la superficie",
		       negoziata_l, negoziata_a, larghezza, altezza);

	/*
	 * Il canale di input, se il compositore l'ha concesso.  Non fallisce il
	 * montaggio se manca: si degrada a sola visione, e lo si dichiara.
	 */
	{
		int fd = mutter_prendi_fd_eis(palco->mutter);

		if (fd >= 0)
		{
			g_autoptr(GError) sbaglio_input = NULL;
			Input *nuovo = input_avvia(fd, mutter_mapping_id(palco->mutter), &sbaglio_input);

			g_rw_lock_writer_lock(&palco->uso_input);
			palco->input = nuovo;
			g_rw_lock_writer_unlock(&palco->uso_input);
			if (!palco->input)
				avviso("input non avviato (%s): la sessione sara' di sola visione",
				       sbaglio_input->message);
		}
		else
		{
			avviso("nessun canale di input: la sessione sara' di sola visione");
		}
	}
	if (palco->input)
		input_misura(palco->input, larghezza, altezza);

	/*
	 * Il sink virtuale, e il suo posto e' QUI perche' e' della SESSIONE.
	 *
	 * Nella sessione senza monitor non esiste alcun dispositivo audio (§7.5 di
	 * REFERENCE.md, misurato): se non lo si crea, le applicazioni non hanno dove
	 * suonare e non c'e' niente da catturare — senza un errore da nessuna parte.
	 *
	 * Non fallisce il montaggio se non riesce: un desktop senza suono e' molto
	 * piu' di nessun desktop, ed e' la regola «degradare, non fallire» di §2 di
	 * SPECIFICA.md.  La cattura vera e propria la accende la connessione, quando
	 * il client avra' negoziato un formato.
	 */
	{
		g_autoptr(GError) sbaglio_suono = NULL;
		Suono *nuovo = suono_apri(&sbaglio_suono);

		g_rw_lock_writer_lock(&palco->uso_suono);
		palco->suono = nuovo;
		g_rw_lock_writer_unlock(&palco->uso_suono);
		if (!nuovo)
			avviso("sink audio non montato (%s): la sessione sara' muta",
			       sbaglio_suono->message);
	}

	/*
	 * Gli appunti della sessione, sulla STESSA sessione di controllo del palco:
	 * Mutter li espone li' (§14.1 di gnome-remote-desktop.md), e chi non ha una
	 * sessione di controllo non ha appunti.  Come per il suono, se non si
	 * accendono non si fallisce il montaggio: si degrada e si dichiara.
	 */
	{
		g_autoptr(GError) sbaglio_appunti = NULL;
		g_autoptr(GDBusConnection) bus = sessione_bus(&sbaglio_appunti);
		Appunti *nuovi = NULL;

		if (bus)
			nuovi = appunti_apri(bus, mutter_percorso_controllo(palco->mutter),
			                     &sbaglio_appunti);

		g_rw_lock_writer_lock(&palco->uso_appunti);
		palco->appunti = nuovi;
		g_rw_lock_writer_unlock(&palco->uso_appunti);
		if (!nuovi)
			avviso("appunti non accesi (%s): niente copia-incolla in questa sessione",
			       sbaglio_appunti->message);
	}

	g_mutex_lock(&palco->lucchetto);
	palco->larghezza = larghezza;
	palco->altezza = altezza;
	g_mutex_unlock(&palco->lucchetto);

	informazione("palco montato: desktop %ux%u, input %s, suono %s, appunti %s", larghezza, altezza,
	             palco->input ? "acceso" : "SPENTO", palco->suono ? "pronto" : "SPENTO",
	             palco->appunti ? "accesi" : "SPENTI");
	stabilizza(palco);
	return TRUE;
}

/*
 * Cambia misura a un palco gia' montato.  Va chiamata con `montaggio` preso.
 */
static gboolean ridimensiona_interno(Palco *palco, uint32_t larghezza, uint32_t altezza,
                                     uint32_t fotogrammi_al_secondo, GError **sbaglio)
{
	g_autoptr(GError) sbaglio_interno = NULL;

	if (palco->larghezza == larghezza && palco->altezza == altezza)
	{
		diagnostica("il palco e' gia' %ux%u: non c'e' niente da ridimensionare", larghezza,
		            altezza);
		return TRUE;
	}

	informazione("ridimensiono il palco: %ux%u → %ux%u", palco->larghezza, palco->altezza,
	             larghezza, altezza);

	if (cattura_ridimensiona(palco->cattura, larghezza, altezza, fotogrammi_al_secondo,
	                         &sbaglio_interno))
	{
		g_mutex_lock(&palco->lucchetto);
		palco->larghezza = larghezza;
		palco->altezza = altezza;
		/* La misura vecchia e' stata segnalata una volta e non vale piu': se la
		 * tela e il fotogramma tornassero a non corrispondere, lo si deve poter
		 * leggere di nuovo. */
		palco->misura_segnalata = FALSE;
		g_mutex_unlock(&palco->lucchetto);

		/*
		 * Le coordinate assolute del puntatore si riscalano su questa misura.
		 * Va detto subito: fra il ridimensionamento e il primo movimento del
		 * mouse non c'e' niente, e un puntatore che finisce a meta' schermo e'
		 * il genere di difetto che si attribuisce al client.
		 *
		 * La REGIONE su cui si riscala, invece, la riannuncia il compositore:
		 * Mutter ricrea il dispositivo virtuale quando il monitor cambia, e
		 * `input.c` rilegge la regione a ogni `DEVICE_ADDED`/`DEVICE_RESUMED`.
		 */
		if (palco->input)
			input_misura(palco->input, larghezza, altezza);

		stabilizza(palco);
		return TRUE;
	}

	/*
	 * Il ripiego, e va dichiarato per nome.
	 *
	 * Rimontare funziona — e' quel che si faceva fino alla fase 5 — ma costa il
	 * conto dei tasti premuti, un monitor virtuale nuovo per GNOME e un secondo
	 * riavvio del decodificatore su Android.  Nel banco della fase 6 la
	 * comparsa di questa riga e' un guasto, non un dettaglio.
	 */
	errore("ridimensionamento a caldo fallito: %s", sbaglio_interno->message);
	avviso("ripiego: rifaccio il palco da capo — si perde lo stato dell'input");
	smonta_interno(palco);
	return monta_interno(palco, larghezza, altezza, fotogrammi_al_secondo, sbaglio);
}

gboolean palco_assicura(Palco *palco, uint32_t larghezza, uint32_t altezza,
                        uint32_t fotogrammi_al_secondo, GError **sbaglio)
{
	gboolean finita;
	gboolean esito;

	g_mutex_lock(&palco->montaggio);

	g_mutex_lock(&palco->lucchetto);
	finita = palco->finita;
	g_mutex_unlock(&palco->lucchetto);

	if (palco->mutter && !finita)
	{
		if (palco->larghezza == larghezza && palco->altezza == altezza)
		{
			diagnostica("palco gia' montato della misura giusta (%ux%u): si riusa", larghezza,
			            altezza);
			g_mutex_unlock(&palco->montaggio);
			return TRUE;
		}

		/*
		 * Chi si ricollega chiedendo un'altra misura non ha bisogno di un palco
		 * nuovo: ne ha bisogno di uno RIDIMENSIONATO.
		 *
		 * Fino alla fase 5 qui si smontava e si rimontava, e il prezzo lo pagava
		 * la sessione: smontare lascia Mutter con zero schermi, e da li'
		 * `libmutter` va in asserzione fallita e le applicazioni aperte perdono
		 * la connessione Wayland (§7.3 di REFERENCE.md).  Con la fase 6 la
		 * strada c'e', ed e' la stessa del ridimensionamento a caldo: chi torna
		 * da un'altra finestra ritrova le proprie finestre dov'erano, solo
		 * disposte diversamente.
		 */
		informazione("chi si collega chiede %ux%u invece di %ux%u: ridimensiono invece di "
		             "rimontare",
		             larghezza, altezza, palco->larghezza, palco->altezza);
		esito = ridimensiona_interno(palco, larghezza, altezza, fotogrammi_al_secondo, sbaglio);
		g_mutex_unlock(&palco->montaggio);
		return esito;
	}

	/* Si smonta PRIMA di rimontare: due monitor virtuali insieme farebbero
	 * credere a GNOME di avere due schermi. */
	if (palco->mutter)
	{
		informazione("il palco va rifatto: %ux%u (la cattura precedente si era chiusa)", larghezza,
		             altezza);
		smonta_interno(palco);
	}

	esito = monta_interno(palco, larghezza, altezza, fotogrammi_al_secondo, sbaglio);
	g_mutex_unlock(&palco->montaggio);
	return esito;
}

gboolean palco_ridimensiona(Palco *palco, uint32_t larghezza, uint32_t altezza,
                            uint32_t fotogrammi_al_secondo, GError **sbaglio)
{
	gboolean finita;
	gboolean esito;

	g_mutex_lock(&palco->montaggio);

	if (!palco->mutter)
	{
		g_mutex_unlock(&palco->montaggio);
		g_set_error(sbaglio, G_IO_ERROR, G_IO_ERROR_NOT_INITIALIZED,
		            "non c'e' nessun palco da ridimensionare");
		return FALSE;
	}

	g_mutex_lock(&palco->lucchetto);
	finita = palco->finita;
	g_mutex_unlock(&palco->lucchetto);
	if (finita)
	{
		g_mutex_unlock(&palco->montaggio);
		g_set_error(sbaglio, G_IO_ERROR, G_IO_ERROR_CLOSED,
		            "la cattura si e' chiusa: non c'e' piu' niente da ridimensionare");
		return FALSE;
	}

	esito = ridimensiona_interno(palco, larghezza, altezza, fotogrammi_al_secondo, sbaglio);
	g_mutex_unlock(&palco->montaggio);
	return esito;
}

Input *palco_input_prendi(Palco *palco)
{
	if (!palco)
		return NULL;
	g_rw_lock_reader_lock(&palco->uso_input);
	return palco->input;
}

void palco_input_lascia(Palco *palco)
{
	if (palco)
		g_rw_lock_reader_unlock(&palco->uso_input);
}

Suono *palco_suono_prendi(Palco *palco)
{
	if (!palco)
		return NULL;
	g_rw_lock_reader_lock(&palco->uso_suono);
	return palco->suono;
}

void palco_suono_lascia(Palco *palco)
{
	if (palco)
		g_rw_lock_reader_unlock(&palco->uso_suono);
}

Appunti *palco_appunti_prendi(Palco *palco)
{
	if (!palco)
		return NULL;
	g_rw_lock_reader_lock(&palco->uso_appunti);
	return palco->appunti;
}

void palco_appunti_lascia(Palco *palco)
{
	if (palco)
		g_rw_lock_reader_unlock(&palco->uso_appunti);
}

EsitoPalco palco_preleva(Palco *palco, Immagine *tela, guint64 *visto)
{
	EsitoPalco esito;

	g_mutex_lock(&palco->lucchetto);

	if (palco->generazione > *visto && palco->ultimo)
	{
		if (!palco->misura_segnalata &&
		    (palco->larghezza_arrivata != immagine_larghezza(tela) ||
		     palco->altezza_arrivata != immagine_altezza(tela)))
		{
			palco->misura_segnalata = TRUE;
			avviso("il fotogramma catturato e' %ux%u ma la tela e' %ux%u: la parte scoperta "
			       "resta grigia",
			       palco->larghezza_arrivata, palco->altezza_arrivata, immagine_larghezza(tela),
			       immagine_altezza(tela));
		}
		immagine_copia_fotogramma(tela, palco->ultimo, palco->passo, palco->larghezza_arrivata,
		                          palco->altezza_arrivata);
		*visto = palco->generazione;
		esito = PALCO_NUOVO;
	}
	else if (palco->finita)
	{
		esito = PALCO_FINITA;
	}
	else
	{
		/* Condizione normale: su un desktop fermo Mutter non manda nulla. */
		esito = PALCO_NIENTE;
	}

	g_mutex_unlock(&palco->lucchetto);
	return esito;
}
