#include "sessione.h"

#include <gio/gio.h>
#include <string.h>

#include "registro.h"

/* Su questa VM, senza accelerazione grafica, la sessione ci mette una decina di
 * secondi: il margine e' per le macchine piu' lente. */
#define ATTESA_AVVIO_MS 40000
#define CADENZA_CONTROLLO_MS 500
#define ATTESA_RISPOSTA_MS 5000

/* Il perche' di questa funzione sta in sessione.h, ed e' una diagnosi costata
 * mezza fase: si legge prima di aggirarla. */
static GMutex lucchetto_bus;
static GDBusConnection *bus_di_sessione;

GDBusConnection *sessione_bus(GError **sbaglio)
{
	GDBusConnection *nostro = NULL;

	g_mutex_lock(&lucchetto_bus);

	/* Il bus dell'utente muore col logout e rinasce subito dopo, sullo stesso
	 * socket ma come demone nuovo.  La connessione vecchia resta li', chiusa:
	 * chi continuasse a usarla non riceverebbe un errore chiaro, riceverebbe
	 * silenzio — nessuna sessione, nessun Mutter, schermo nero al secondo
	 * accesso.  Quindi la si butta e se ne apre un'altra. */
	if (bus_di_sessione && g_dbus_connection_is_closed(bus_di_sessione))
	{
		diagnostica("il bus di sessione si e' chiuso: se ne apre uno nuovo");
		g_clear_object(&bus_di_sessione);
	}

	if (!bus_di_sessione)
	{
		g_autofree char *indirizzo =
		    g_dbus_address_get_for_bus_sync(G_BUS_TYPE_SESSION, NULL, sbaglio);

		/*
		 * Connessione NOSTRA, non quella condivisa di `g_bus_get_sync`.
		 *
		 * Sono due cose diverse, e la differenza si paga: la condivisa e' un
		 * oggetto unico per tutto il processo, che GIO tiene in una cache e a cui
		 * accende «exit-on-close».  Aprendola noi, l'interruttore nasce spento e
		 * il ricambio dopo il logout dipende solo da questa funzione, non da come
		 * GIO gestisce la propria cache.
		 */
		if (indirizzo)
			bus_di_sessione = g_dbus_connection_new_for_address_sync(
			    indirizzo,
			    G_DBUS_CONNECTION_FLAGS_AUTHENTICATION_CLIENT |
			        G_DBUS_CONNECTION_FLAGS_MESSAGE_BUS_CONNECTION,
			    NULL, NULL, sbaglio);
		if (bus_di_sessione)
			g_dbus_connection_set_exit_on_close(bus_di_sessione, FALSE);
	}

	if (bus_di_sessione)
		nostro = g_object_ref(bus_di_sessione);
	g_mutex_unlock(&lucchetto_bus);
	return nostro;
}

gboolean sessione_viva(void)
{
	g_autoptr(GDBusConnection) bus = NULL;
	g_autoptr(GVariant) risposta = NULL;

	bus = sessione_bus(NULL);
	if (!bus)
		return FALSE;

	/*
	 * Il tipo della risposta e' dichiarato NULL apposta.
	 *
	 * `GetCurrentState` restituisce l'intera configurazione degli schermi, una
	 * struttura annidata che cambia forma fra le versioni di Mutter.
	 * Dichiararla significherebbe che un domani la vitalita' della sessione
	 * dipende dall'esattezza di quella dichiarazione — ed e' esattamente cosi'
	 * che la prima stesura dava per morta una sessione partita benissimo.
	 * Qui interessa una cosa sola: che la risposta arrivi.
	 */
	risposta = g_dbus_connection_call_sync(
	    bus, "org.gnome.Mutter.DisplayConfig", "/org/gnome/Mutter/DisplayConfig",
	    "org.gnome.Mutter.DisplayConfig", "GetCurrentState", NULL, NULL, G_DBUS_CALL_FLAGS_NONE,
	    ATTESA_RISPOSTA_MS, NULL, NULL);
	return risposta != NULL;
}

/*
 * Una locale UTF-8, sempre.
 *
 * Non e' pignoleria: `gnome-terminal-server` si rifiuta di partire con una
 * locale non UTF-8 («Non UTF-8 locale (ANSI_X3.4-1968) is not supported!»,
 * uscita 8), e l'utente si ritrova un desktop in cui i programmi semplicemente
 * non si aprono, senza un errore da nessuna parte.
 */
static const char *locale_utf8(void)
{
	const char *lingua = g_getenv("LANG");
	g_autofree char *maiuscolo = NULL;

	if (!lingua || !*lingua)
		return "C.UTF-8";
	maiuscolo = g_ascii_strup(lingua, -1);
	if (strstr(maiuscolo, "UTF-8") || strstr(maiuscolo, "UTF8"))
		return lingua;

	avviso("la locale dell'ambiente («%s») non e' UTF-8: la sessione partira' con C.UTF-8",
	       lingua);
	return "C.UTF-8";
}

/* L'ambiente della sessione, costruito da zero: quel che non serve non passa. */
static char **componi_ambiente(GError **sbaglio)
{
	GPtrArray *ambiente = g_ptr_array_new_with_free_func(g_free);
	const char *runtime = g_getenv("XDG_RUNTIME_DIR");
	const char *bus = g_getenv("DBUS_SESSION_BUS_ADDRESS");
	g_autofree char *bus_dedotto = NULL;

	if (!runtime || !*runtime)
	{
		g_set_error(sbaglio, G_IO_ERROR, G_IO_ERROR_FAILED,
		            "XDG_RUNTIME_DIR non impostata: non so dove vive la sessione");
		g_ptr_array_free(ambiente, TRUE);
		return NULL;
	}
	if (!bus || !*bus)
	{
		/* Il bus di sessione sta convenzionalmente li' dentro; dedurlo e'
		 * meglio che rinunciare, perche' un ambiente da cui la variabile manca
		 * — un'unita' systemd, per esempio — e' del tutto normale. */
		bus_dedotto = g_strdup_printf("unix:path=%s/bus", runtime);
		bus = bus_dedotto;
		diagnostica("DBUS_SESSION_BUS_ADDRESS assente: uso %s", bus);
	}

	g_ptr_array_add(ambiente, g_strdup_printf("XDG_RUNTIME_DIR=%s", runtime));
	g_ptr_array_add(ambiente, g_strdup_printf("DBUS_SESSION_BUS_ADDRESS=%s", bus));
	/* La sessione deve DICHIARARSI, o le applicazioni di GNOME non si
	 * riconoscono a casa propria e si fermano da sole (§5.6). */
	g_ptr_array_add(ambiente, g_strdup("XDG_CURRENT_DESKTOP=GNOME"));
	g_ptr_array_add(ambiente, g_strdup("XDG_SESSION_DESKTOP=gnome"));
	/*
	 * Qui XDG_SESSION_TYPE=wayland SERVE, e non e' la bugia punita in §5.6.
	 * L'unita' della Shell porta `ConditionEnvironment=XDG_SESSION_TYPE=wayland`:
	 * senza, il compositore non viene avviato affatto e la sessione parte monca
	 * senza che nessuno spieghi perche'.  La differenza con il caso punito e'
	 * che li' la si dichiarava AL POSTO di una sessione, qui DENTRO una
	 * sessione che esiste davvero e che la esporta ai propri servizi.
	 */
	g_ptr_array_add(ambiente, g_strdup("XDG_SESSION_TYPE=wayland"));
	g_ptr_array_add(ambiente, g_strdup_printf("LANG=%s", locale_utf8()));
	g_ptr_array_add(ambiente, g_strdup_printf("HOME=%s", g_get_home_dir()));
	g_ptr_array_add(ambiente, g_strdup_printf("USER=%s", g_get_user_name()));
	g_ptr_array_add(ambiente, g_strdup_printf("PATH=%s", g_getenv("PATH") ?: "/usr/bin:/bin"));
	g_ptr_array_add(ambiente, NULL);

	return (char **) g_ptr_array_free(ambiente, FALSE);
}

static gboolean avvia(const char *comando, GError **sbaglio)
{
	g_auto(GStrv) ambiente = NULL;
	g_autofree char *registro = NULL;
	g_autofree char *riga = NULL;
	/* `setsid --fork` stacca la sessione dal nostro gruppo di processi: se
	 * REMOTIX viene riavviato, il desktop dell'utente non se ne accorge. */
	char *argv[] = { "setsid", "--fork", "sh", "-c", NULL, NULL };
	int stato = 0;

	ambiente = componi_ambiente(sbaglio);
	if (!ambiente)
		return FALSE;

	registro = g_build_filename(g_getenv("XDG_RUNTIME_DIR"), "remotix-sessione.log", NULL);
	riga = g_strdup_printf("exec >>'%s' 2>&1; %s", registro, comando);
	argv[4] = riga;

	informazione("avvio la sessione grafica: %s (registro in %s)", comando, registro);
	if (!g_spawn_sync(g_get_home_dir(), argv, ambiente, G_SPAWN_SEARCH_PATH, NULL, NULL, NULL,
	                  NULL, &stato, sbaglio))
		return FALSE;
	return g_spawn_check_wait_status(stato, sbaglio);
}

gboolean sessione_assicura(const char *comando, gboolean *avviata, GError **sbaglio)
{
	gint64 scadenza;

	if (avviata)
		*avviata = FALSE;

	if (sessione_viva())
	{
		diagnostica("la sessione grafica c'e' gia'");
		return TRUE;
	}

	informazione("nessuna sessione grafica: la avvio");
	if (!avvia(comando ?: SESSIONE_COMANDO_PREDEFINITO, sbaglio))
		return FALSE;

	scadenza = g_get_monotonic_time() + (gint64) ATTESA_AVVIO_MS * 1000;
	while (g_get_monotonic_time() < scadenza)
	{
		g_usleep(CADENZA_CONTROLLO_MS * 1000);
		if (sessione_viva())
		{
			informazione("sessione grafica pronta");
			if (avviata)
				*avviata = TRUE;
			return TRUE;
		}
	}

	g_set_error(sbaglio, G_IO_ERROR, G_IO_ERROR_TIMED_OUT,
	            "la sessione grafica non ha risposto entro %d secondi", ATTESA_AVVIO_MS / 1000);
	return FALSE;
}

/* Quanto si aspetta che la sessione se ne vada dopo averglielo chiesto con
 * garbo, prima di insistere. */
#define ATTESA_USCITA_MS 10000

/* `org.gnome.SessionManager.Logout`: 0 chiede conferma, 1 no, 2 forza. */
static gboolean esci(guint32 modo, GError **sbaglio)
{
	g_autoptr(GDBusConnection) bus = sessione_bus(sbaglio);
	g_autoptr(GVariant) risposta = NULL;

	if (!bus)
		return FALSE;
	risposta = g_dbus_connection_call_sync(
	    bus, "org.gnome.SessionManager", "/org/gnome/SessionManager", "org.gnome.SessionManager",
	    "Logout", g_variant_new("(u)", modo), NULL, G_DBUS_CALL_FLAGS_NONE, ATTESA_RISPOSTA_MS,
	    NULL, sbaglio);
	return risposta != NULL;
}

static gboolean aspetta_che_finisca(void)
{
	gint64 scadenza = g_get_monotonic_time() + (gint64) ATTESA_USCITA_MS * 1000;

	while (g_get_monotonic_time() < scadenza)
	{
		g_usleep(CADENZA_CONTROLLO_MS * 1000);
		if (!sessione_viva())
			return TRUE;
	}
	return FALSE;
}

gboolean sessione_termina(GError **sbaglio)
{
	if (!sessione_viva())
		return FALSE;

	informazione("chiedo alla sessione grafica di uscire");
	if (!esci(1, sbaglio))
		return FALSE;
	if (aspetta_che_finisca())
	{
		informazione("la sessione grafica e' uscita");
		return TRUE;
	}

	avviso("la sessione non esce: la chiudo a forza, cio' che non e' salvato va perduto");
	if (!esci(2, sbaglio))
		return FALSE;
	if (aspetta_che_finisca())
		return TRUE;

	g_set_error(sbaglio, G_IO_ERROR, G_IO_ERROR_TIMED_OUT,
	            "la sessione grafica non e' uscita nemmeno a forza");
	return FALSE;
}
