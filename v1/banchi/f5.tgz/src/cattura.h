/*
 * cattura — i pixel, letti dal nodo PipeWire che Mutter ha aperto.
 *
 * ⛔ LO STRIDE SI LEGGE DAL CHUNK DEL BUFFER, mai calcolato come
 *    `larghezza * 4`.  Il produttore allinea le righe come gli conviene, e
 *    dedurlo produce immagini oblique (§5.6 di SPECIFICA.md; vale anche per il
 *    riferimento, §11.4 di gnome-remote-desktop.md).
 *
 * ⛔ NIENTE DMA-BUF, per ora: NON si dichiara il campo `modifier` nel formato
 *    proposto.  La negoziazione DMA-BUF parte solo se il consumatore annuncia i
 *    modificatori che sa importare; tacendo, si ottiene memoria condivisa senza
 *    dover aggiungere altro.  Il percorso DMA-BUF e' materia della fase 9.
 *
 * ⛔ LA CADENZA SI DICHIARA A ZERO, con un massimo a intervallo: significa
 *    «mandami un fotogramma quando cambia qualcosa, non a ritmo fisso», che e'
 *    esattamente il comportamento che serve a un desktop remoto.  Ne discende
 *    che su un desktop fermo NON ARRIVA NULLA — comportamento voluto, non
 *    guasto, ed e' la ragione per cui esiste R9.
 *
 * Il ciclo di PipeWire vive su un thread suo (`pw_thread_loop`): e' sincrono e
 * bloccante, e mescolarlo con qualunque altro ciclo significa bloccarsi a
 * vicenda.  Le due richiamate qui sotto vengono quindi chiamate DA QUEL THREAD:
 * chi le scrive non deve aspettare nulla al loro interno, e in particolare non
 * deve chiamare `cattura_ferma` da dentro `CatturaFine`.
 */
#pragma once

#include <glib.h>
#include <stdint.h>

typedef struct Cattura Cattura;

/* Un fotogramma appena arrivato.  I pixel sono BGRX a 32 bit e vivono solo per
 * la durata della chiamata: chi li vuole se li copia. */
typedef void (*CatturaFotogramma)(const uint8_t *pixel, uint32_t passo, uint32_t larghezza,
                                  uint32_t altezza, gpointer dati);

/* Il flusso si e' staccato: o la sessione grafica e' finita — un «Esci» dal
 * menu di sistema — oppure Mutter l'ha fermato per conto suo. */
typedef void (*CatturaFine)(gpointer dati);

/*
 * Avvia la lettura dal nodo indicato, chiedendo la misura voluta.
 *
 * La misura si dichiara perche' si sta riprendendo un MONITOR VIRTUALE: non
 * esiste uno schermo da cui dedurla, ed e' il consumatore a dire quanto grande
 * lo vuole.  E' la base della risoluzione dinamica della fase 6.
 */
Cattura *cattura_avvia(uint32_t nodo, uint32_t larghezza, uint32_t altezza,
                       uint32_t fotogrammi_al_secondo, CatturaFotogramma su_fotogramma,
                       CatturaFine su_fine, gpointer dati, GError **sbaglio);

/* La misura davvero negoziata con Mutter, che puo' non essere quella chiesta. */
void cattura_misura_negoziata(const Cattura *cattura, uint32_t *larghezza, uint32_t *altezza);

void cattura_ferma(Cattura *cattura);
