/*
 * codificatore — i due codec della pipeline EGFX.
 *
 * REMOTIX ne porta due e sceglie fra loro UNA VOLTA, al CapsConfirm, in base
 * ai flag dichiarati dal client (R3 di REFERENCE.md):
 *
 *   AVC disponibile   →  AVC420               Windows, Linux
 *   AVC_DISABLED      →  RemoteFX Progressive  Android
 *
 * Mandare AVC420 a chi ha dichiarato AVC_DISABLED produce schermo nero: il
 * client riscontra i fotogrammi e non disegna.  E' esattamente cio' che fa
 * Remote Desktop Manager, misurato il 3 agosto.
 *
 * Nota sull'encoder: entrambi vengono da FreeRDP (`avc420_compress` e
 * `progressive_compress`, API pubbliche usate anche dal suo shadow server).
 * §3.1 di SPECIFICA.md prevede `libavcodec` per poter scegliere il
 * codificatore per nome a runtime: quella ragione resta valida e vale per la
 * fase 9, ma qui dietro c'e' gia' una selezione di sottosistema (x264,
 * OpenH264, VA-API) e il controllo del bitrate.  L'interfaccia sotto tiene la
 * scelta confinata: cambiarla e' cambiare questo file.
 */
#pragma once

#include <freerdp/channels/rdpgfx.h>
#include <freerdp/codec/h264.h>
#include <freerdp/codec/progressive.h>
#include <glib.h>

typedef enum
{
	CODIFICATORE_AVC420,
	CODIFICATORE_PROGRESSIVE,
} TipoCodificatore;

typedef struct Codificatore Codificatore;

Codificatore *codificatore_nuovo(TipoCodificatore tipo, uint32_t larghezza_allineata,
                                 uint32_t altezza_allineata, uint32_t bitrate_kbit,
                                 uint32_t fotogrammi_al_secondo);
void codificatore_libera(Codificatore *cod);

const char *codificatore_nome(const Codificatore *cod);

/*
 * Comprime la regione utile e riempie `cmd`.
 *
 * `larghezza`/`altezza` sono la misura VERA del desktop, non quella allineata:
 * i rettangoli descrivono il contenuto, non la superficie (R5).  I bordi sono
 * ESCLUSIVI — misurato sui byte il 4 agosto.
 *
 * Restituisce FALSE se non c'e' niente da mandare o se la compressione
 * fallisce; in caso di successo il chiamante deve spedire `cmd` e poi chiamare
 * codificatore_rilascia().
 */
gboolean codificatore_comprimi(Codificatore *cod, const uint8_t *pixel, uint32_t passo,
                               uint32_t larghezza_allineata, uint32_t altezza_allineata,
                               uint32_t larghezza, uint32_t altezza,
                               RDPGFX_SURFACE_COMMAND *cmd);

void codificatore_rilascia(Codificatore *cod);
