#include "palco.h"

#include <string.h>

#include "cattura.h"
#include "mutter.h"
#include "registro.h"

/* Quanto silenzio basta per dire che il desktop ha finito di ridisegnarsi. */
#define QUIETE_RIDISEGNO_MS 300
/* Quanti fotogrammi servono prima di fidarsi del silenzio (R10). */
#define FOTOGRAMMI_PRIMA_DI_FIDARSI 2
/* E quanto si e' disposti ad aspettare in tutto, perche' un desktop che cambia
 * di continuo non tenga fermo il primo fotogramma all'infinito. */
#define ATTESA_RIDISEGNO_MS 2500

struct Palco
{
	/* Due lucchetti, con due compiti distinti: `montaggio` serializza chi monta
	 * e smonta — piu' connessioni possono chiederlo insieme — e `lucchetto`
	 * protegge il solo fotogramma, che e' l'unica cosa toccata dal thread di
	 * PipeWire.  Tenerne uno solo significherebbe che una connessione che monta
	 * blocca la cattura di quella che sta gia' disegnando. */
	GMutex montaggio;
	GMutex lucchetto;
	GCond novita;

	MutterSessione *mutter;
	Cattura *cattura;
	Input *input;

	/* La misura chiesta, cioe' quella del palco montato. */
	uint32_t larghezza, altezza;

	/* L'ultimo fotogramma, e nient'altro: di una raffica conta l'ultimo. */
	uint8_t *ultimo;
	gsize capienza;
	uint32_t passo, larghezza_arrivata, altezza_arrivata;
	guint64 generazione;

	gboolean finita;
	gboolean misura_segnalata;
};

/* ------------------------------------------------------------------ *
 * Le due richiamate, chiamate DAL THREAD DI PIPEWIRE
 * ------------------------------------------------------------------ */
static void su_fotogramma(const uint8_t *pixel, uint32_t passo, uint32_t larghezza,
                          uint32_t altezza, gpointer dati)
{
	Palco *palco = dati;
	gsize servono = (gsize) passo * altezza;

	g_mutex_lock(&palco->lucchetto);
	if (palco->capienza < servono)
	{
		g_free(palco->ultimo);
		palco->ultimo = g_malloc(servono);
		palco->capienza = servono;
	}
	memcpy(palco->ultimo, pixel, servono);
	palco->passo = passo;
	palco->larghezza_arrivata = larghezza;
	palco->altezza_arrivata = altezza;
	palco->generazione++;
	g_cond_broadcast(&palco->novita);
	g_mutex_unlock(&palco->lucchetto);
}

static void su_fine(gpointer dati)
{
	Palco *palco = dati;

	/*
	 * Qui si segna e basta.  Chiamare `cattura_ferma` da dentro una richiamata
	 * di PipeWire significherebbe fermare il ciclo da dentro il ciclo: si
	 * smonta dal thread della connessione, che se ne accorge al giro dopo.
	 */
	g_mutex_lock(&palco->lucchetto);
	palco->finita = TRUE;
	g_cond_broadcast(&palco->novita);
	g_mutex_unlock(&palco->lucchetto);
}

/* ------------------------------------------------------------------ *
 * Ciclo di vita
 * ------------------------------------------------------------------ */
Palco *palco_nuovo(void)
{
	Palco *palco = g_new0(Palco, 1);

	g_mutex_init(&palco->montaggio);
	g_mutex_init(&palco->lucchetto);
	g_cond_init(&palco->novita);
	return palco;
}

/* Va chiamata con `montaggio` preso e `lucchetto` LIBERO: `cattura_ferma`
 * aspetta il thread di PipeWire, che potrebbe essere fermo proprio sul
 * lucchetto dentro `su_fotogramma`. */
static void smonta_interno(Palco *palco)
{
	/* L'input per primo: i suoi dispositivi virtuali appartengono alla sessione
	 * di controllo, e chiuderla sotto di lui lo lascerebbe a parlare nel vuoto. */
	g_clear_pointer(&palco->input, input_ferma);
	g_clear_pointer(&palco->cattura, cattura_ferma);
	g_clear_pointer(&palco->mutter, mutter_chiudi);

	g_mutex_lock(&palco->lucchetto);
	palco->larghezza = palco->altezza = 0;
	palco->finita = FALSE;
	palco->misura_segnalata = FALSE;
	/*
	 * La generazione NON si azzera, e non e' un dettaglio: un'altra connessione
	 * puo' essere in corso e avere gia' visto il fotogramma numero 500.
	 * Ripartendo da zero, per lei nulla sarebbe piu' «nuovo» e resterebbe ferma
	 * sull'immagine di prima per sempre — un difetto che si presenterebbe solo
	 * con due client sovrapposti, cioe' a intermittenza e mai a comando.
	 */
	g_mutex_unlock(&palco->lucchetto);
}

void palco_smonta(Palco *palco)
{
	if (!palco)
		return;
	g_mutex_lock(&palco->montaggio);
	if (palco->mutter)
	{
		smonta_interno(palco);
		informazione("palco smontato");
	}
	g_mutex_unlock(&palco->montaggio);
}

void palco_libera(Palco *palco)
{
	if (!palco)
		return;
	palco_smonta(palco);
	g_free(palco->ultimo);
	g_cond_clear(&palco->novita);
	g_mutex_clear(&palco->lucchetto);
	g_mutex_clear(&palco->montaggio);
	g_free(palco);
}

/*
 * Aspetta che il desktop si sia RIDISEGNATO alla misura nuova (R10).
 *
 * Si raccolgono i fotogrammi finche' non smettono di arrivare, e ci si fida del
 * silenzio solo dopo il secondo: il primo dopo un cambio di misura e' quello
 * vuoto, e il silenzio fra lui e quello buono e' la trappola.
 */
static void stabilizza(Palco *palco)
{
	gint64 scadenza = g_get_monotonic_time() + (gint64) ATTESA_RIDISEGNO_MS * 1000;
	guint raccolti = 0;
	guint64 vista;

	g_mutex_lock(&palco->lucchetto);
	vista = palco->generazione;
	while (g_get_monotonic_time() < scadenza)
	{
		gint64 fine_quiete = g_get_monotonic_time() + (gint64) QUIETE_RIDISEGNO_MS * 1000;

		if (!g_cond_wait_until(&palco->novita, &palco->lucchetto, fine_quiete))
		{
			/* Silenzio. */
			if (raccolti >= FOTOGRAMMI_PRIMA_DI_FIDARSI)
				break;
			continue;
		}
		if (palco->finita)
			break;
		if (palco->generazione > vista)
		{
			raccolti += (guint) (palco->generazione - vista);
			vista = palco->generazione;
		}
	}
	g_mutex_unlock(&palco->lucchetto);

	diagnostica("atteso il ridisegno alla misura nuova: %u fotogrammi raccolti", raccolti);
}

gboolean palco_assicura(Palco *palco, uint32_t larghezza, uint32_t altezza,
                        uint32_t fotogrammi_al_secondo, GError **sbaglio)
{
	uint32_t negoziata_l = 0, negoziata_a = 0;
	gboolean finita;

	g_mutex_lock(&palco->montaggio);

	g_mutex_lock(&palco->lucchetto);
	finita = palco->finita;
	g_mutex_unlock(&palco->lucchetto);

	if (palco->mutter && !finita && palco->larghezza == larghezza && palco->altezza == altezza)
	{
		diagnostica("palco gia' montato della misura giusta (%ux%u): si riusa", larghezza,
		            altezza);
		g_mutex_unlock(&palco->montaggio);
		return TRUE;
	}

	/* Si smonta PRIMA di rimontare: due monitor virtuali insieme farebbero
	 * credere a GNOME di avere due schermi. */
	if (palco->mutter)
	{
		informazione("il palco va rifatto: %ux%u%s", larghezza, altezza,
		             finita ? " (la cattura precedente si era chiusa)" : "");
		smonta_interno(palco);
	}

	palco->mutter = mutter_apri(sbaglio);
	if (!palco->mutter)
	{
		g_mutex_unlock(&palco->montaggio);
		return FALSE;
	}

	palco->cattura = cattura_avvia(mutter_nodo(palco->mutter), larghezza, altezza,
	                               fotogrammi_al_secondo, su_fotogramma, su_fine, palco, sbaglio);
	if (!palco->cattura)
	{
		g_clear_pointer(&palco->mutter, mutter_chiudi);
		g_mutex_unlock(&palco->montaggio);
		return FALSE;
	}

	/*
	 * Se Mutter ha negoziato una misura diversa da quella chiesta, lo si dice
	 * FORTE e subito.  Il sintomo altrimenti sarebbe un desktop che copre solo
	 * una parte della superficie — e quel sintomo, quando comparve il 3 agosto,
	 * costo' una caccia che finì in una questione aperta.
	 */
	cattura_misura_negoziata(palco->cattura, &negoziata_l, &negoziata_a);
	if (negoziata_l && (negoziata_l != larghezza || negoziata_a != altezza))
		errore("Mutter ha negoziato %ux%u invece dei %ux%u chiesti: il desktop non coprira' "
		       "tutta la superficie",
		       negoziata_l, negoziata_a, larghezza, altezza);

	/*
	 * Il canale di input, se il compositore l'ha concesso.  Non fallisce il
	 * montaggio se manca: si degrada a sola visione, e lo si dichiara.
	 */
	{
		int fd = mutter_prendi_fd_eis(palco->mutter);

		if (fd >= 0)
		{
			g_autoptr(GError) sbaglio_input = NULL;

			palco->input = input_avvia(fd, mutter_mapping_id(palco->mutter), &sbaglio_input);
			if (!palco->input)
				avviso("input non avviato (%s): la sessione sara' di sola visione",
				       sbaglio_input->message);
		}
		else
		{
			avviso("nessun canale di input: la sessione sara' di sola visione");
		}
	}
	if (palco->input)
		input_misura(palco->input, larghezza, altezza);

	g_mutex_lock(&palco->lucchetto);
	palco->larghezza = larghezza;
	palco->altezza = altezza;
	g_mutex_unlock(&palco->lucchetto);

	informazione("palco montato: desktop %ux%u, input %s", larghezza, altezza,
	             palco->input ? "acceso" : "SPENTO");
	stabilizza(palco);
	g_mutex_unlock(&palco->montaggio);
	return TRUE;
}

Input *palco_input(Palco *palco)
{
	return palco ? palco->input : NULL;
}

EsitoPalco palco_preleva(Palco *palco, Immagine *tela, guint64 *visto)
{
	EsitoPalco esito;

	g_mutex_lock(&palco->lucchetto);

	if (palco->generazione > *visto && palco->ultimo)
	{
		if (!palco->misura_segnalata &&
		    (palco->larghezza_arrivata != immagine_larghezza(tela) ||
		     palco->altezza_arrivata != immagine_altezza(tela)))
		{
			palco->misura_segnalata = TRUE;
			avviso("il fotogramma catturato e' %ux%u ma la tela e' %ux%u: la parte scoperta "
			       "resta grigia",
			       palco->larghezza_arrivata, palco->altezza_arrivata, immagine_larghezza(tela),
			       immagine_altezza(tela));
		}
		immagine_copia_fotogramma(tela, palco->ultimo, palco->passo, palco->larghezza_arrivata,
		                          palco->altezza_arrivata);
		*visto = palco->generazione;
		esito = PALCO_NUOVO;
	}
	else if (palco->finita)
	{
		esito = PALCO_FINITA;
	}
	else
	{
		/* Condizione normale: su un desktop fermo Mutter non manda nulla. */
		esito = PALCO_NIENTE;
	}

	g_mutex_unlock(&palco->lucchetto);
	return esito;
}
