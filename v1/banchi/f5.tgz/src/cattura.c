#include "cattura.h"

#include <gio/gio.h>
#include <pipewire/pipewire.h>
#include <spa/param/video/format-utils.h>
#include <spa/utils/result.h>

#include "registro.h"

/* Quanto si aspetta che il flusso arrivi a `paused`: e' il momento in cui la
 * negoziazione del formato e' avvenuta e si sa se Mutter ha accettato la misura
 * chiesta.  Senza questa attesa un rifiuto — «no more input formats» — sarebbe
 * silenzioso, e si manifesterebbe molto piu' tardi come schermo nero. */
#define ATTESA_AVVIO_S 10

struct Cattura
{
	struct pw_thread_loop *ciclo;
	struct pw_context *contesto;
	struct pw_core *nucleo;
	struct pw_stream *flusso;
	struct spa_hook gancio;

	struct spa_video_info_raw formato;
	gboolean formato_noto;

	CatturaFotogramma su_fotogramma;
	CatturaFine su_fine;
	gpointer dati;

	enum pw_stream_state stato;
	char *guasto;
	gboolean fine_segnalata;
	gboolean primo_fotogramma;
};

static void su_stato(void *dati, enum pw_stream_state vecchio, enum pw_stream_state nuovo,
                     const char *errore)
{
	Cattura *cattura = dati;

	diagnostica("stato del flusso di cattura: %s → %s%s%s", pw_stream_state_as_string(vecchio),
	            pw_stream_state_as_string(nuovo), errore ? " — " : "", errore ? errore : "");
	cattura->stato = nuovo;
	if (errore)
	{
		g_free(cattura->guasto);
		cattura->guasto = g_strdup(errore);
	}

	/*
	 * Il ciclo deve accorgersi da se' quando il flusso si stacca, e la
	 * condizione sullo stato VECCHIO non e' un dettaglio: all'avvio si parte da
	 * `unconnected`, e uscire li' sarebbe uscire prima di cominciare.
	 *
	 * Senza questo, un «Esci» dal menu di sistema lascerebbe il client
	 * attaccato a un'immagine congelata: chi legge non distinguerebbe «desktop
	 * fermo» da «non c'e' piu' niente da catturare», e sul registro non
	 * comparirebbe nulla.
	 */
	if ((vecchio == PW_STREAM_STATE_PAUSED || vecchio == PW_STREAM_STATE_STREAMING) &&
	    nuovo == PW_STREAM_STATE_UNCONNECTED && !cattura->fine_segnalata)
	{
		cattura->fine_segnalata = TRUE;
		informazione("il flusso di cattura si e' staccato");
		if (cattura->su_fine)
			cattura->su_fine(cattura->dati);
	}

	pw_thread_loop_signal(cattura->ciclo, false);
}

static void su_parametri(void *dati, uint32_t id, const struct spa_pod *param)
{
	Cattura *cattura = dati;
	uint32_t tipo, sottotipo;

	if (!param || id != SPA_PARAM_Format)
		return;
	if (spa_format_parse(param, &tipo, &sottotipo) < 0)
		return;
	if (tipo != SPA_MEDIA_TYPE_video || sottotipo != SPA_MEDIA_SUBTYPE_raw)
		return;
	if (spa_format_video_raw_parse(param, &cattura->formato) < 0)
	{
		avviso("formato di cattura non interpretabile");
		return;
	}

	cattura->formato_noto = TRUE;
	informazione("formato negoziato con Mutter: %ux%u, %s", cattura->formato.size.width,
	             cattura->formato.size.height,
	             cattura->formato.format == SPA_VIDEO_FORMAT_BGRx ? "BGRx" : "BGRA");
	pw_thread_loop_signal(cattura->ciclo, false);
}

static void su_processo(void *dati)
{
	Cattura *cattura = dati;
	struct pw_buffer *pacco;
	struct spa_data *piano;
	uint32_t passo, altezza;
	size_t disponibili;

	pacco = pw_stream_dequeue_buffer(cattura->flusso);
	if (!pacco)
		return;

	if (pacco->buffer->n_datas == 0)
		goto restituisci;
	piano = &pacco->buffer->datas[0];
	if (!piano->data || !piano->chunk)
		goto restituisci;

	/* Lo stride autorevole e' questo, non `larghezza * 4`. */
	passo = (uint32_t) MAX(0, piano->chunk->stride);
	if (passo == 0 || piano->chunk->size == 0)
		goto restituisci;

	altezza = cattura->formato.size.height;
	disponibili = piano->maxsize > (uint32_t) piano->chunk->offset
	                  ? piano->maxsize - (uint32_t) piano->chunk->offset
	                  : 0;
	if ((size_t) passo * altezza > disponibili)
		altezza = (uint32_t) (disponibili / passo);
	if (altezza == 0)
		goto restituisci;

	if (cattura->primo_fotogramma)
	{
		cattura->primo_fotogramma = FALSE;
		informazione("primo fotogramma dal desktop: %ux%u, passo %u",
		             cattura->formato.size.width, altezza, passo);
	}

	cattura->su_fotogramma((const uint8_t *) piano->data + piano->chunk->offset, passo,
	                       cattura->formato.size.width, altezza, cattura->dati);

restituisci:
	pw_stream_queue_buffer(cattura->flusso, pacco);
}

static const struct pw_stream_events eventi = {
	PW_VERSION_STREAM_EVENTS,
	.state_changed = su_stato,
	.param_changed = su_parametri,
	.process = su_processo,
};

/*
 * Il formato che REMOTIX dichiara di saper leggere.
 *
 * Solo formati a 32 bit con i canali nell'ordine che il codificatore si
 * aspetta.  Elencarne altri sarebbe un difetto silenzioso: nessun punto della
 * catena guarda il formato davvero negoziato, quindi se Mutter scegliesse una
 * variante RGB, rosso e blu uscirebbero scambiati senza alcun errore.
 *
 * ⚠ SULLA MISURA C'E' UNA DIVERGENZA DA MISURARE (§11.1 di
 *   gnome-remote-desktop.md).  REMOTIX ha misurato che un rettangolo SINGOLO
 *   viene respinto da Mutter con «no more input formats» e ha dovuto dichiarare
 *   un intervallo chiuso (min = pref = max); il riferimento dichiara un valore
 *   singolo e funziona.  Le spiegazioni possibili sono tre: la versione di
 *   Mutter, `is-platform: true` in `RecordVirtual` — che REMOTIX ora dichiara —
 *   oppure il fatto che il riferimento propone due formati e Mutter negozia sul
 *   secondo.
 *
 *   Si parte quindi dalla forma pulita, il valore singolo, e si tiene
 *   l'intervallo chiuso a portata di variabile d'ambiente
 *   (`REMOTIX_MISURA_INTERVALLO=1`) per poterli confrontare senza ricompilare.
 *   Quando la misura sara' fatta, questa nota va sostituita dall'esito.
 */
static const struct spa_pod *formato_richiesto(struct spa_pod_builder *costruttore,
                                               uint32_t larghezza, uint32_t altezza,
                                               uint32_t fotogrammi_al_secondo)
{
	struct spa_rectangle misura = SPA_RECTANGLE(larghezza, altezza);
	struct spa_fraction cadenza = SPA_FRACTION(0, 1);
	struct spa_fraction cadenza_minima = SPA_FRACTION(1, 1);
	struct spa_fraction cadenza_massima = SPA_FRACTION(MAX(1u, fotogrammi_al_secondo), 1);
	const char *intervallo = g_getenv("REMOTIX_MISURA_INTERVALLO");

	if (intervallo && *intervallo == '1')
	{
		diagnostica("misura dichiarata come intervallo chiuso");
		return spa_pod_builder_add_object(
		    costruttore, SPA_TYPE_OBJECT_Format, SPA_PARAM_EnumFormat, SPA_FORMAT_mediaType,
		    SPA_POD_Id(SPA_MEDIA_TYPE_video), SPA_FORMAT_mediaSubtype,
		    SPA_POD_Id(SPA_MEDIA_SUBTYPE_raw), SPA_FORMAT_VIDEO_format,
		    SPA_POD_CHOICE_ENUM_Id(3, SPA_VIDEO_FORMAT_BGRx, SPA_VIDEO_FORMAT_BGRx,
		                           SPA_VIDEO_FORMAT_BGRA),
		    SPA_FORMAT_VIDEO_size, SPA_POD_CHOICE_RANGE_Rectangle(&misura, &misura, &misura),
		    SPA_FORMAT_VIDEO_framerate, SPA_POD_Fraction(&cadenza), SPA_FORMAT_VIDEO_maxFramerate,
		    SPA_POD_CHOICE_RANGE_Fraction(&cadenza_massima, &cadenza_minima, &cadenza_massima));
	}

	return spa_pod_builder_add_object(
	    costruttore, SPA_TYPE_OBJECT_Format, SPA_PARAM_EnumFormat, SPA_FORMAT_mediaType,
	    SPA_POD_Id(SPA_MEDIA_TYPE_video), SPA_FORMAT_mediaSubtype,
	    SPA_POD_Id(SPA_MEDIA_SUBTYPE_raw), SPA_FORMAT_VIDEO_format,
	    SPA_POD_CHOICE_ENUM_Id(3, SPA_VIDEO_FORMAT_BGRx, SPA_VIDEO_FORMAT_BGRx,
	                           SPA_VIDEO_FORMAT_BGRA),
	    SPA_FORMAT_VIDEO_size, SPA_POD_Rectangle(&misura), SPA_FORMAT_VIDEO_framerate,
	    SPA_POD_Fraction(&cadenza), SPA_FORMAT_VIDEO_maxFramerate,
	    SPA_POD_CHOICE_RANGE_Fraction(&cadenza_massima, &cadenza_minima, &cadenza_massima));
}

Cattura *cattura_avvia(uint32_t nodo, uint32_t larghezza, uint32_t altezza,
                       uint32_t fotogrammi_al_secondo, CatturaFotogramma su_fotogramma,
                       CatturaFine su_fine, gpointer dati, GError **sbaglio)
{
	static gsize inizializzato = 0;
	Cattura *cattura = g_new0(Cattura, 1);
	uint8_t spazio[1024];
	struct spa_pod_builder costruttore = SPA_POD_BUILDER_INIT(spazio, sizeof spazio);
	const struct spa_pod *parametri[1];
	gint64 scadenza;

	if (g_once_init_enter(&inizializzato))
	{
		pw_init(NULL, NULL);
		g_once_init_leave(&inizializzato, 1);
	}

	cattura->su_fotogramma = su_fotogramma;
	cattura->su_fine = su_fine;
	cattura->dati = dati;
	cattura->primo_fotogramma = TRUE;

	cattura->ciclo = pw_thread_loop_new("remotix-cattura", NULL);
	if (!cattura->ciclo)
	{
		g_set_error(sbaglio, G_IO_ERROR, G_IO_ERROR_FAILED, "ciclo PipeWire non creato");
		goto guasto;
	}
	cattura->contesto = pw_context_new(pw_thread_loop_get_loop(cattura->ciclo), NULL, 0);
	if (!cattura->contesto)
	{
		g_set_error(sbaglio, G_IO_ERROR, G_IO_ERROR_FAILED, "contesto PipeWire non creato");
		goto guasto;
	}

	pw_thread_loop_lock(cattura->ciclo);
	if (pw_thread_loop_start(cattura->ciclo) < 0)
	{
		pw_thread_loop_unlock(cattura->ciclo);
		g_set_error(sbaglio, G_IO_ERROR, G_IO_ERROR_FAILED, "thread di PipeWire non avviato");
		goto guasto;
	}

	cattura->nucleo = pw_context_connect(cattura->contesto, NULL, 0);
	if (!cattura->nucleo)
	{
		pw_thread_loop_unlock(cattura->ciclo);
		g_set_error(sbaglio, G_IO_ERROR, G_IO_ERROR_FAILED, "connessione a PipeWire fallita");
		goto guasto;
	}

	cattura->flusso = pw_stream_new(
	    cattura->nucleo, "remotix-cattura",
	    pw_properties_new(PW_KEY_MEDIA_TYPE, "Video", PW_KEY_MEDIA_CATEGORY, "Capture",
	                      PW_KEY_MEDIA_ROLE, "Screen", NULL));
	if (!cattura->flusso)
	{
		pw_thread_loop_unlock(cattura->ciclo);
		g_set_error(sbaglio, G_IO_ERROR, G_IO_ERROR_FAILED, "flusso PipeWire non creato");
		goto guasto;
	}
	pw_stream_add_listener(cattura->flusso, &cattura->gancio, &eventi, cattura);

	parametri[0] = formato_richiesto(&costruttore, larghezza, altezza, fotogrammi_al_secondo);
	if (pw_stream_connect(cattura->flusso, PW_DIRECTION_INPUT, nodo,
	                      PW_STREAM_FLAG_AUTOCONNECT | PW_STREAM_FLAG_MAP_BUFFERS |
	                          PW_STREAM_FLAG_RT_PROCESS,
	                      parametri, 1) < 0)
	{
		pw_thread_loop_unlock(cattura->ciclo);
		g_set_error(sbaglio, G_IO_ERROR, G_IO_ERROR_FAILED, "aggancio al nodo %u fallito", nodo);
		goto guasto;
	}

	/* Si aspetta la negoziazione: e' l'unico punto in cui un rifiuto del
	 * formato si vede subito invece di diventare uno schermo nero piu' tardi. */
	scadenza = g_get_monotonic_time() + (gint64) ATTESA_AVVIO_S * G_USEC_PER_SEC;
	while (cattura->stato != PW_STREAM_STATE_PAUSED &&
	       cattura->stato != PW_STREAM_STATE_STREAMING &&
	       cattura->stato != PW_STREAM_STATE_ERROR && g_get_monotonic_time() < scadenza)
		pw_thread_loop_timed_wait(cattura->ciclo, 1);
	pw_thread_loop_unlock(cattura->ciclo);

	if (cattura->stato == PW_STREAM_STATE_ERROR)
	{
		g_set_error(sbaglio, G_IO_ERROR, G_IO_ERROR_FAILED, "cattura rifiutata da Mutter: %s",
		            cattura->guasto ? cattura->guasto : "senza spiegazione");
		goto guasto;
	}
	if (cattura->stato != PW_STREAM_STATE_PAUSED && cattura->stato != PW_STREAM_STATE_STREAMING)
	{
		g_set_error(sbaglio, G_IO_ERROR, G_IO_ERROR_TIMED_OUT,
		            "la cattura non ha dato segno di vita entro %d secondi", ATTESA_AVVIO_S);
		goto guasto;
	}

	informazione("cattura avviata sul nodo %u", nodo);
	return cattura;

guasto:
	cattura_ferma(cattura);
	return NULL;
}

void cattura_misura_negoziata(const Cattura *cattura, uint32_t *larghezza, uint32_t *altezza)
{
	*larghezza = cattura->formato_noto ? cattura->formato.size.width : 0;
	*altezza = cattura->formato_noto ? cattura->formato.size.height : 0;
}

void cattura_ferma(Cattura *cattura)
{
	if (!cattura)
		return;

	/*
	 * Prima si ferma il thread, poi si distrugge il resto.
	 *
	 * Fermandolo per primo non serve piu' prendere il lucchetto per toccare gli
	 * oggetti di PipeWire, e soprattutto non si rischia di distruggere il flusso
	 * mentre una richiamata lo sta usando.
	 */
	if (cattura->ciclo)
		pw_thread_loop_stop(cattura->ciclo);
	if (cattura->flusso)
		pw_stream_destroy(cattura->flusso);
	if (cattura->nucleo)
		pw_core_disconnect(cattura->nucleo);
	if (cattura->contesto)
		pw_context_destroy(cattura->contesto);
	if (cattura->ciclo)
		pw_thread_loop_destroy(cattura->ciclo);

	g_free(cattura->guasto);
	g_free(cattura);
}
