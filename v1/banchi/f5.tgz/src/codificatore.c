#include "codificatore.h"

#include <freerdp/codec/color.h>
#include <freerdp/codec/region.h>

#include "registro.h"

struct Codificatore
{
	TipoCodificatore tipo;

	H264_CONTEXT *h264;
	RDPGFX_AVC420_BITMAP_STREAM avc420;
	gboolean metablock_da_liberare;

	PROGRESSIVE_CONTEXT *progressive;
};

Codificatore *codificatore_nuovo(TipoCodificatore tipo, uint32_t larghezza_allineata,
                                 uint32_t altezza_allineata, uint32_t bitrate_kbit,
                                 uint32_t fotogrammi_al_secondo)
{
	Codificatore *cod = g_new0(Codificatore, 1);
	cod->tipo = tipo;

	if (tipo == CODIFICATORE_AVC420)
	{
		UINT32 valore;

		cod->h264 = h264_context_new(TRUE);
		if (!cod->h264)
		{
			errore("nessun codificatore H.264 disponibile in FreeRDP");
			g_free(cod);
			return NULL;
		}

		/*
		 * R11: mai fotogrammi B, mai codifica di campo — cioe' Constrained
		 * High.  Il profilo lo impone il sottosistema di FreeRDP, che codifica
		 * in tempo reale; qui si dichiara l'uso, che e' il modo di chiederlo.
		 */
		valore = H264_SCREEN_CONTENT_REAL_TIME;
		h264_context_set_option(cod->h264, H264_CONTEXT_OPTION_USAGETYPE, valore);

		/* Il controllo del bitrate c'e', contro quanto si credeva: si dichiara
		 * un obiettivo invece di lasciare il quantizzatore costante come fa
		 * gnome-remote-desktop. Il punto di lavoro vero e' materia di fase 7. */
		valore = H264_RATECONTROL_VBR;
		h264_context_set_option(cod->h264, H264_CONTEXT_OPTION_RATECONTROL, valore);
		valore = bitrate_kbit * 1000;
		h264_context_set_option(cod->h264, H264_CONTEXT_OPTION_BITRATE, valore);
		valore = fotogrammi_al_secondo;
		h264_context_set_option(cod->h264, H264_CONTEXT_OPTION_FRAMERATE, valore);

		if (!h264_context_reset(cod->h264, larghezza_allineata, altezza_allineata))
		{
			errore("h264_context_reset fallita per %ux%u", larghezza_allineata, altezza_allineata);
			h264_context_free(cod->h264);
			g_free(cod);
			return NULL;
		}
	}
	else
	{
		cod->progressive = progressive_context_new(TRUE);
		if (!cod->progressive)
		{
			errore("nessun codificatore RemoteFX Progressive disponibile");
			g_free(cod);
			return NULL;
		}
		if (!progressive_context_reset(cod->progressive))
		{
			errore("progressive_context_reset fallita");
			progressive_context_free(cod->progressive);
			g_free(cod);
			return NULL;
		}
	}

	return cod;
}

void codificatore_libera(Codificatore *cod)
{
	if (!cod)
		return;
	codificatore_rilascia(cod);
	if (cod->h264)
		h264_context_free(cod->h264);
	if (cod->progressive)
		progressive_context_free(cod->progressive);
	g_free(cod);
}

const char *codificatore_nome(const Codificatore *cod)
{
	return cod->tipo == CODIFICATORE_AVC420 ? "AVC420" : "RemoteFX Progressive";
}

gboolean codificatore_comprimi(Codificatore *cod, const uint8_t *pixel, uint32_t passo,
                               uint32_t larghezza_allineata, uint32_t altezza_allineata,
                               uint32_t larghezza, uint32_t altezza, RDPGFX_SURFACE_COMMAND *cmd)
{
	/* Bordi ESCLUSIVI, e sul contenuto vero: la superficie e' allineata, i
	 * rettangoli no.  Misurato sui byte il 4 agosto (R5). */
	RECTANGLE_16 regione = {
		.left = 0,
		.top = 0,
		.right = (UINT16) larghezza,
		.bottom = (UINT16) altezza,
	};

	cmd->left = 0;
	cmd->top = 0;
	cmd->right = larghezza;
	cmd->bottom = altezza;
	cmd->format = PIXEL_FORMAT_BGRX32;

	if (cod->tipo == CODIFICATORE_AVC420)
	{
		INT32 esito;

		memset(&cod->avc420, 0, sizeof cod->avc420);
		esito = avc420_compress(cod->h264, pixel, cmd->format, passo, larghezza_allineata,
		                        altezza_allineata, &regione, &cod->avc420.data, &cod->avc420.length,
		                        &cod->avc420.meta);
		if (esito < 0)
		{
			errore("avc420_compress fallita");
			return FALSE;
		}
		cod->metablock_da_liberare = TRUE;
		if (esito == 0)
			return FALSE; /* niente di nuovo da mandare */

		cmd->codecId = RDPGFX_CODECID_AVC420;
		cmd->extra = &cod->avc420;
		return TRUE;
	}
	else
	{
		REGION16 regione16;
		INT32 esito;

		region16_init(&regione16);
		region16_union_rect(&regione16, &regione16, &regione);
		esito = progressive_compress(cod->progressive, pixel, passo * altezza_allineata,
		                             cmd->format, larghezza_allineata, altezza_allineata, passo,
		                             &regione16, &cmd->data, &cmd->length);
		region16_uninit(&regione16);

		if (esito < 0)
		{
			errore("progressive_compress fallita");
			return FALSE;
		}
		if (esito == 0)
			return FALSE;

		cmd->codecId = RDPGFX_CODECID_CAPROGRESSIVE;
		return TRUE;
	}
}

void codificatore_rilascia(Codificatore *cod)
{
	if (cod->metablock_da_liberare)
	{
		free_h264_metablock(&cod->avc420.meta);
		cod->metablock_da_liberare = FALSE;
	}
}
