/*
 * REMOTIX — server RDP per Linux.
 *
 * Questo file resta cio' che era nella fase 1: opzioni, registro, segnali e
 * uscita pulita.  Il protocollo sta in `server.c`, la cattura del desktop in
 * `palco.c` e nei due moduli che ne dipendono, `mutter.c` e `cattura.c`.
 *
 * ⛔ Prima di toccare qualunque cosa che riguardi il protocollo, si legge
 *    REFERENCE.md — e' regola vincolante (§7.0 di SPECIFICA.md).  Le
 *    incompatibilita' raccolte li' non si manifestano come errori: si
 *    manifestano come schermo nero su un client su tre.
 */
#include <freerdp/freerdp.h>
#include <glib.h>
#include <glib-unix.h>
#include <stdlib.h>

#include <freerdp/error.h>

#include "autenticazione.h"
#include "registro.h"
#include "sentinella.h"
#include "sessione.h"
#include "server.h"
#include "uscita.h"

typedef struct
{
	GMainLoop *ciclo;
	Server *server;
	Sentinella *sentinella;
	Uscita *uscita;
	int codice_uscita;
} Remotix;

/* ------------------------------------------------------------------ *
 * Le due reazioni della fase 5
 * ------------------------------------------------------------------ */
static void sgombera(Remotix *remotix, gboolean da_chiudere);

/*
 * L'utente e' uscito dalla sessione.
 *
 * Gira sul thread di `uscita`, subito dopo che il riscontro a gnome-session e'
 * partito, e non fa altro che segnare e svegliare: il client deve cadere adesso,
 * non fra cinque secondi, e con il motivo scritto in chiaro.
 *
 * `ERRINFO_LOGOFF_BY_USER` dice esattamente cosa e' successo, ed e' il congedo
 * che fino al passaggio a FreeRDP era a debito: chi riceve solo una chiusura di
 * socket resta a fissare l'ultimo fotogramma — che dopo un logout e' uno sfondo
 * pulito, cioe' visivamente identico a un desktop vivo.
 */
static void su_uscita_sessione(gpointer dati)
{
	Remotix *remotix = dati;

	server_congeda_tutti(remotix->server, ERRINFO_LOGOFF_BY_USER,
	                     "l'utente e' uscito dalla sessione");

	/* La sessione se n'e' andata da sola: resta da smontare il palco, e lo fa
	 * un thread a parte perche' qui non si deve aspettare nulla. */
	sgombera(remotix, FALSE);
}

/*
 * Sgombera: chiude la sessione grafica remota quando ne compare una locale.
 *
 * Gira su un thread suo perche' aspetta secondi — `Logout(1)` e poi, se serve,
 * `Logout(2)` — e chi la chiama e' la sentinella, che nel frattempo deve
 * continuare a ripassare.
 *
 * ⛔ Non basta staccare il client.  Se il compositore remoto restasse in piedi,
 *    chi si siede davanti alla macchina avrebbe due sessioni grafiche a proprio
 *    nome sullo stesso `$XDG_RUNTIME_DIR`, e la seconda troverebbe il nome
 *    D-Bus `org.gnome.Shell` gia' occupato: il difetto si vedrebbe sulla
 *    sessione LOCALE che non parte, cioe' dove nessuno lo cerca.
 */
typedef struct
{
	Remotix *remotix;
	/* Vero quando la sessione va CHIUSA da noi (comparsa di una locale); falso
	 * quando se n'e' gia' andata da sola (l'utente e' uscito). */
	gboolean da_chiudere;
} Sgombero;

static gpointer thread_sgombera(gpointer dati)
{
	Sgombero *sgombero = dati;
	g_autoptr(GError) sbaglio = NULL;

	if (sgombero->da_chiudere && !sessione_termina(&sbaglio) && sbaglio)
		avviso("sessione grafica remota non chiusa: %s", sbaglio->message);

	/* In entrambi i casi il palco va giu': gli oggetti che lo compongono
	 * appartengono a un compositore che non c'e' piu'. */
	server_smonta_palco(sgombero->remotix->server);
	g_free(sgombero);
	return NULL;
}

static void sgombera(Remotix *remotix, gboolean da_chiudere)
{
	Sgombero *sgombero = g_new0(Sgombero, 1);
	GThread *thread;

	sgombero->remotix = remotix;
	sgombero->da_chiudere = da_chiudere;
	thread = g_thread_new("remotix-sgombera", thread_sgombera, sgombero);
	g_thread_unref(thread);
}

static void su_sessione_locale(gboolean presente, const char *descrizione, gpointer dati)
{
	Remotix *remotix = dati;

	if (!presente)
		return;

	/* Prima il client — subito, e dichiarando perche' — poi la sessione. */
	server_congeda_tutti(remotix->server, ERRINFO_DISCONNECTED_BY_OTHER_CONNECTION,
	                     "la sessione locale ha la precedenza");
	sgombera(remotix, TRUE);
}

static gint porta = 3389;
static gchar *indirizzo = NULL;
static gchar *nome_livello = NULL;
static gchar *certificato = NULL;
static gchar *chiave = NULL;
static gint bitrate = 10000;
static gint fotogrammi = 30;
static gboolean senza_autenticazione = FALSE;
static gboolean immagine_di_prova = FALSE;
static gchar *comando_sessione = NULL;
static gboolean mostra_versione = FALSE;

static GOptionEntry opzioni[] = {
	{ "porta", 'p', 0, G_OPTION_ARG_INT, &porta, "Porta su cui ascoltare (predefinita: 3389)",
	  "NUMERO" },
	{ "indirizzo", 'a', 0, G_OPTION_ARG_STRING, &indirizzo,
	  "Indirizzo su cui ascoltare (predefinito: tutti)", "IND" },
	{ "registro", 'r', 0, G_OPTION_ARG_STRING, &nome_livello, "Livello del registro", "LIVELLO" },
	{ "certificato", 0, 0, G_OPTION_ARG_FILENAME, &certificato,
	  "Certificato TLS in PEM (se manca, se ne genera uno)", "FILE" },
	{ "chiave", 0, 0, G_OPTION_ARG_FILENAME, &chiave, "Chiave privata TLS in PEM", "FILE" },
	{ "bitrate", 0, 0, G_OPTION_ARG_INT, &bitrate, "Bitrate video in kbit/s (predefinito: 10000)",
	  "KBIT" },
	{ "fotogrammi", 0, 0, G_OPTION_ARG_INT, &fotogrammi,
	  "Fotogrammi al secondo (predefinito: 30)", "N" },
	{ "senza-autenticazione", 0, 0, G_OPTION_ARG_NONE, &senza_autenticazione,
	  "NON autentica nessuno: solo per il banco di prova", NULL },
	{ "immagine-di-prova", 0, 0, G_OPTION_ARG_NONE, &immagine_di_prova,
	  "Manda la scena sintetica invece del desktop: isola il protocollo dalla cattura", NULL },
	{ "sessione", 0, 0, G_OPTION_ARG_STRING, &comando_sessione,
	  "Comando con cui avviare la sessione grafica se manca", "COMANDO" },
	{ "versione", 'V', 0, G_OPTION_ARG_NONE, &mostra_versione, "Mostra la versione ed esce", NULL },
	/* Le opzioni del progetto sono in italiano come tutto il resto, ma
	 * «--version» e' quello che chiunque prova per primo, e PIANO.md lo indica
	 * come la prova visibile della fase 1: si accetta anche quello. */
	{ "version", 0, G_OPTION_FLAG_HIDDEN, G_OPTION_ARG_NONE, &mostra_versione, NULL, NULL },
	{ NULL, 0, 0, 0, NULL, NULL, NULL },
};

static void stampa_versione(void)
{
	g_print("REMOTIX %s\n", PACCHETTO_VERSIONE);
	g_print("  FreeRDP   %s (%s)\n", freerdp_get_version_string(), freerdp_get_build_revision());
	g_print("  GLib      %u.%u.%u\n", glib_major_version, glib_minor_version, glib_micro_version);
}

/*
 * I due segnali di arresto.
 *
 * g_unix_signal_add non esegue nulla dentro il gestore di segnale vero: mette
 * in coda una sorgente sul ciclo principale, che viene servita fra un giro e
 * l'altro.  Serve perche' qui dentro, piu' avanti, ci sara' da smontare
 * sessioni e rilasciare tasti rimasti premuti (R6 di REFERENCE.md §6.1): cose
 * che in un gestore di segnale asincrono non si possono fare.
 */
static gboolean su_arresto(gpointer dati)
{
	Remotix *remotix = dati;

	informazione("arresto richiesto, chiudo");
	g_main_loop_quit(remotix->ciclo);
	return G_SOURCE_REMOVE;
}

int main(int argc, char **argv)
{
	Remotix remotix = { .codice_uscita = EXIT_SUCCESS };
	LivelloRegistro livello = REGISTRO_INFORMAZIONE;
	g_autoptr(GError) sbaglio = NULL;
	g_autoptr(GOptionContext) contesto = NULL;

	contesto = g_option_context_new("- server RDP per Linux");
	g_option_context_add_main_entries(contesto, opzioni, NULL);
	{
		g_autofree char *coda =
		    g_strdup_printf("Livelli del registro: %s.", registro_nomi_livelli());
		g_option_context_set_description(contesto, coda);
	}

	if (!g_option_context_parse(contesto, &argc, &argv, &sbaglio))
	{
		g_printerr("%s\n", sbaglio->message);
		return EXIT_FAILURE;
	}

	if (mostra_versione)
	{
		stampa_versione();
		return EXIT_SUCCESS;
	}

	/* Il livello si accetta anche dall'ambiente, che e' comodo quando il server
	 * lo avvia un'unita' systemd e la riga di comando non si tocca. */
	const char *dall_ambiente = g_getenv("REMOTIX_REGISTRO");
	const char *scelto = nome_livello ? nome_livello : dall_ambiente;
	if (scelto && !registro_livello_da_nome(scelto, &livello))
	{
		g_printerr("livello di registro sconosciuto: «%s»\nQuelli accettati sono: %s.\n", scelto,
		           registro_nomi_livelli());
		return EXIT_FAILURE;
	}

	registro_avvia(livello);

	if (porta < 1 || porta > 65535)
	{
		errore("porta fuori intervallo: %d", porta);
		return EXIT_FAILURE;
	}

	informazione("REMOTIX %s — FreeRDP %s", PACCHETTO_VERSIONE, freerdp_get_version_string());
	diagnostica("livello del registro: %s", scelto ? scelto : "informazione");

	/* §3.4 — un server che non sa di chi sia la sessione che serve non deve
	 * aprire la porta.  Si dichiara all'avvio, perche' su ogni rifiuto si
	 * scriveranno tutti e due i nomi. */
	if (!senza_autenticazione)
	{
		const char *atteso = autenticazione_utente_atteso();
		if (!atteso)
		{
			errore("non riesco a stabilire di quale utente e' la sessione: non parto");
			return EXIT_FAILURE;
		}
		informazione("servo la sessione di «%s»", atteso);
	}

	{
		g_autofree char *cert_predefinito = NULL;
		g_autofree char *chiave_predefinita = NULL;
		OpzioniServer impostazioni = { 0 };

		if (!certificato || !chiave)
		{
			g_autofree char *cartella =
			    g_build_filename(g_get_user_data_dir(), "remotix", NULL);
			g_mkdir_with_parents(cartella, 0700);
			cert_predefinito = g_build_filename(cartella, "certificato.pem", NULL);
			chiave_predefinita = g_build_filename(cartella, "chiave.pem", NULL);
		}

		impostazioni.porta = (uint16_t) porta;
		impostazioni.indirizzo = indirizzo;
		impostazioni.certificato = certificato ?: cert_predefinito;
		impostazioni.chiave = chiave ?: chiave_predefinita;
		impostazioni.bitrate_kbit = (uint32_t) MAX(100, bitrate);
		impostazioni.fotogrammi_al_secondo = (uint32_t) CLAMP(fotogrammi, 1, 120);
		impostazioni.senza_autenticazione = senza_autenticazione;
		impostazioni.immagine_di_prova = immagine_di_prova;
		impostazioni.comando_sessione = comando_sessione;

		remotix.server = server_nuovo(&impostazioni, &sbaglio);
		if (!remotix.server)
		{
			errore("%s", sbaglio->message);
			return EXIT_FAILURE;
		}
		if (!server_avvia(remotix.server, &sbaglio))
		{
			errore("%s", sbaglio->message);
			server_libera(remotix.server);
			return EXIT_FAILURE;
		}
	}

	remotix.ciclo = g_main_loop_new(NULL, FALSE);
	g_unix_signal_add(SIGINT, su_arresto, &remotix);
	g_unix_signal_add(SIGTERM, su_arresto, &remotix);

	/*
	 * Le due sorveglianze partono DOPO il server, perche' entrambe possono
	 * reagire subito e hanno bisogno di trovarlo pronto.  La sentinella fa il
	 * suo primo controllo prima di tornare: se una sessione grafica locale c'e'
	 * gia', non deve esistere una finestra iniziale in cui si entra lo stesso.
	 */
	if (!immagine_di_prova)
	{
		remotix.sentinella = sentinella_avvia(su_sessione_locale, &remotix);
		server_sentinella(remotix.server, remotix.sentinella);
		remotix.uscita = uscita_avvia(su_uscita_sessione, &remotix);
	}

	g_main_loop_run(remotix.ciclo);

	/* Si spengono le sorveglianze PRIMA del server: reagiscono chiamandolo, e
	 * una reazione che arrivasse a server gia' liberato userebbe memoria
	 * liberata. */
	uscita_ferma(remotix.uscita);
	sentinella_ferma(remotix.sentinella);
	server_libera(remotix.server);

	/* L'uscita e' esplicita e ordinata: e' l'abitudine che in fase 5 diventera'
	 * lo smontaggio del palco e il congedo dichiarato al client (R12). */
	g_main_loop_unref(remotix.ciclo);
	g_free(indirizzo);
	g_free(certificato);
	g_free(chiave);
	g_free(nome_livello);
	g_free(comando_sessione);
	informazione("chiuso");
	return remotix.codice_uscita;
}
