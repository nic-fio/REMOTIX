/*
 * palco — cattura e monitor virtuale, montati una volta e tenuti in piedi.
 *
 * # R9: l'ultimo fotogramma si conserva e si rispedisce
 *
 * Mutter manda un fotogramma SOLO quando qualcosa cambia.  Un fotogramma
 * arrivato prima che il client abbia finito di negoziare non si puo' disegnare,
 * e su un desktop fermo non ne arrivera' un altro: il client resta nero a tempo
 * indeterminato.  Il difetto e' insidioso perche' SI CORREGGE DA SE' appena
 * qualcuno muove qualcosa, quindi in prova sembra un ritardo d'avvio.
 *
 * Qui l'ultimo fotogramma vive in un posto solo, sempre disponibile, e ogni
 * connessione tiene il conto di quale ha gia' visto: chi arriva trova subito
 * qualcosa da disegnare.
 *
 * # R10: dopo un rimontaggio si aspetta il ridisegno
 *
 * Quando il monitor virtuale cambia misura, Mutter manda un fotogramma SUBITO,
 * prima che GNOME abbia ridisegnato: lo sfondo e' ancora quello della misura
 * vecchia e il resto e' vuoto.  Misurato in PNG fuori dalla catena RDP, ne manda
 * due — il primo con il solo colore di fondo, il secondo completo — e poi tace.
 * Con R9 quell'immagine parziale RESTA.  Si aspetta quindi il silenzio, ma
 * fidandosene solo dopo il secondo fotogramma: il silenzio fra il primo e il
 * secondo e' esattamente dove cadeva la prima stesura di questa attesa.
 *
 * # Perche' il palco appartiene al SERVER e non alla connessione
 *
 * Perche' smontarlo alla disconnessione lascia Mutter con ZERO schermi, e da
 * li' `libmutter` va in asserzione fallita
 * (`meta_workspace_get_work_area_for_monitor: logical_monitor != NULL`), le
 * applicazioni aperte perdono la connessione Wayland con «Error 71 (Protocol
 * error)» e quelle nuove non hanno dove aprirsi.  E' la questione aperta n.5 di
 * `SPECIFICA.md`, gia' colta sul fatto il 3 agosto.
 *
 * Fase 5 lo prevede come proprio contenuto — «il palco appartiene alla
 * sessione, non alla connessione» — ma anticiparlo qui non e' zelo: la prova
 * della fase 3 e' «il desktop vero SUI TRE CLIENT», cioe' tre connessioni una
 * dopo l'altra, che e' precisamente la sequenza che quel difetto rovina.  In
 * dote arriva anche il riaggancio: chi si ricollega alla stessa misura ritrova
 * il desktop com'era, senza rifare la cattura.
 */
#pragma once

#include <glib.h>
#include <stdint.h>

#include "immagine.h"
#include "input.h"

typedef struct Palco Palco;

typedef enum
{
	PALCO_NUOVO,  /* c'e' un fotogramma piu' recente, ed e' stato copiato */
	PALCO_NIENTE, /* il desktop e' fermo: condizione NORMALE, non un guasto */
	PALCO_FINITA, /* la cattura si e' chiusa: la sessione grafica non c'e' piu' */
} EsitoPalco;

Palco *palco_nuovo(void);
void palco_libera(Palco *palco);

/*
 * Assicura che ci sia un palco della misura chiesta.
 *
 * Se c'e' gia' ed e' della misura giusta non tocca nulla: e' il caso del client
 * che si riaggancia.  Altrimenti smonta e rimonta, e aspetta il ridisegno.
 */
gboolean palco_assicura(Palco *palco, uint32_t larghezza, uint32_t altezza,
                        uint32_t fotogrammi_al_secondo, GError **sbaglio);

/*
 * Copia nella tela l'ultimo fotogramma, se e' piu' recente di quello che il
 * chiamante ha gia' visto.  `visto` va inizializzato a 0 e viene aggiornato.
 */
EsitoPalco palco_preleva(Palco *palco, Immagine *tela, guint64 *visto);

/* Smonta tutto.  Si usa allo spegnimento, non alla disconnessione. */
void palco_smonta(Palco *palco);

/*
 * Il canale di input verso il compositore, o NULL se la sessione e' di sola
 * visione.
 *
 * Appartiene al palco per lo stesso motivo per cui gli appartiene la cattura:
 * i dispositivi virtuali vivono quanto la sessione di controllo, e quella nasce
 * e muore col monitor virtuale.  Chi si collega li trova gia' pronti.
 *
 * ⛔ VA PRESO E LASCIATO, non semplicemente letto, e non e' cerimonia: il palco
 *    si smonta da un thread — la sessione esce, compare una sessione locale —
 *    mentre le connessioni stanno ancora inoltrando tasti.  Leggere il
 *    puntatore e usarlo dopo significa usare memoria liberata, e il sintomo e'
 *    un segfault dentro glib in un thread «remotix-peer», cioe' lontanissimo
 *    dalla causa.  Misurato il 4 agosto, due volte, in `dmesg`.
 *
 *    Fra `prendi` e `lascia` lo smontaggio ASPETTA.  Chi sta in mezzo non deve
 *    quindi fare nulla di lungo: accodare un evento, e basta.
 */
Input *palco_input_prendi(Palco *palco);
void palco_input_lascia(Palco *palco);
